﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using IBM.WMQ;
using System.Data;
using System.Runtime.Caching;
using Binternacional.Transversal;

namespace Binternacional.MQ
{
    public class MQ
    {


        private TimeSpan objTiempoEspera = new TimeSpan(0, 0, 30);
        private string strNombreAdministradorColas;
        private string strCanal;
        private string strNombreConexion;
        private bool blnEjecutadoCorrectamente;


        /// <summary>
        /// parametrizacion En Cache Evitar muliples llamadas a la BD por ejecucion de transacciones
        /// </summary>
        private int strfechaCore = 0;
        private int strhoraCiclo1Hasta = 0;
        private int strhoraCiclo1Desde = 0;
        private int strhoraCiclo2Desde = 0;
        private int strhoraCiclo2Hasta = 0;

        public string NombreAdministradorColas
        {
            get
            {
                if (string.IsNullOrEmpty(this.strNombreAdministradorColas))
                    this.strNombreAdministradorColas = Binternacional.Transversal.Util.getlistaParametros("NombreAdministradorColas", "Configuracion");
                return this.strNombreAdministradorColas;
            }
            set
            {
                this.strNombreAdministradorColas = value;
            }
        }

        public string Canal
        {
            get
            {
                if (string.IsNullOrEmpty(this.strCanal))
                    this.strCanal = Binternacional.Transversal.Util.getlistaParametros("Canal", "Configuracion");
                return this.strCanal;
            }
            set
            {
                this.strCanal = value;
            }
        }


        public string NombreConexion
        {
            get
            {
                if (string.IsNullOrEmpty(this.strNombreConexion))
                    this.strNombreConexion = Binternacional.Transversal.Util.getlistaParametros("NombreConexion", "Configuracion");
                return strNombreConexion;

            }
            set
            {
                this.strNombreConexion = value;
            }
        }

        public TimeSpan TiempoEspera
        {
            get
            {
                return this.objTiempoEspera;
            }
            set
            {
                this.objTiempoEspera = value;
            }
        }

        public bool EjecutadoCorrectamente
        {
            get
            {
                return this.blnEjecutadoCorrectamente;
            }
            private set
            {
                this.blnEjecutadoCorrectamente = value;
            }
        }


        public int FechaCore
        {
            get
            {
                int horaCore = 0;
                ///valida Horario con fin de llamar servicio en Linea
                if (DateTime.Now.Hour >= int.Parse(Util.getlistaParametros("HoraDesdeLLamadaOnline", "Configuracion")) && DateTime.Now.Hour <= int.Parse(Util.getlistaParametros("HoraHastaLLamadaOnline", "Configuracion")))
                {
                    ///obtiene hora de flexcube
                    horaCore = ServiciosWeb.ObtieneHoraCore();

                    ///si la hora esta al limite del cambio de ciclo se otorga un delay para no ocacionar problemas con las cuadraturas
                    if (horaCore >= int.Parse(Util.getlistaParametros("HORADESDECICLO1", "Configuracion")) && horaCore <= int.Parse(Util.getlistaParametros("HORAHASTACICLO1", "Configuracion")))
                        System.Threading.Thread.Sleep(3000);

                    strfechaCore = ServiciosWeb.ObtieneFechaCore();

                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                    theComponente.Mensaje = "Obteniendo Fecha Core Online Ciclo 1" + strfechaCore.ToString();
                    theComponente.Metodo = "FechaCore";
                    Log.ins_error(theComponente);
                }
                ///valida Horario con fin de llamar servicio en Linea
                if (DateTime.Now.Hour >= int.Parse(Util.getlistaParametros("HoraDesdeCiclo2LLamadaOnline", "Configuracion")) && DateTime.Now.Hour <= int.Parse(Util.getlistaParametros("HoraHastaCiclo2LLamadaOnline", "Configuracion")))
                {
                    ///obtiene hora de flexcube
                    horaCore = ServiciosWeb.ObtieneHoraCore();

                    ///si la hora esta al limite del cambio de ciclo se otorga un delay para no ocacionar problemas con las cuadraturas
                    if (horaCore >= int.Parse(Util.getlistaParametros("HORADESDECICLO2", "Configuracion")) && horaCore <= int.Parse(Util.getlistaParametros("HORAHASTACICLO2", "Configuracion")))
                        System.Threading.Thread.Sleep(3000);

                    strfechaCore = ServiciosWeb.ObtieneFechaCore();

                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                    theComponente.Mensaje = "Obteniendo Fecha Core Online Ciclo 2" + strfechaCore.ToString();
                    theComponente.Metodo = "FechaCore";
                    Log.ins_error(theComponente);
                }
                var cache = MemoryCache.Default;
                if (cache.Get("fechaCore") == null)
                {

                    ///obtengo Servicio
                    strfechaCore = ServiciosWeb.ObtieneFechaCore();

                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    /// se modifica duracion de chache servidor desde Front END
                    policy.AbsoluteExpiration = Convert.ToDateTime(Util.getlistaParametros("CacheServicio", "Configuracion"));
                    policy.SlidingExpiration = TimeSpan.FromSeconds(3000);
                    ///se agrega valor de servicio en cache
                    cache.Set("fechaCore", strfechaCore, policy.AbsoluteExpiration);


                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                    theComponente.Mensaje = "Obteniendo Fecha Core" + strfechaCore.ToString();
                    theComponente.Metodo = "FechaCore";
                    Log.ins_error(theComponente);

                }
                else
                {

                    strfechaCore = int.Parse(cache["fechaCore"].ToString());

                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                    theComponente.Mensaje = "Obteniendo Fecha Core Desde el Cache Servidor" + strfechaCore.ToString();
                    theComponente.Metodo = "FechaCore";
                    Log.ins_error(theComponente);

                }
                return this.strfechaCore;
            }
            set
            {
                this.strfechaCore = value;
            }
        }
        public int HoraCiclo1Desde
        {
            get
            {
                this.strhoraCiclo1Desde = int.Parse(Binternacional.Transversal.Util.getlistaParametros("HORADESDECICLO1", "Configuracion"));
                return this.strhoraCiclo1Desde;
            }
            set
            {
                this.strhoraCiclo1Desde = value;
            }
        }
        public int HoraCiclo1Hasta
        {
            get
            {
                this.strhoraCiclo1Hasta = int.Parse(Binternacional.Transversal.Util.getlistaParametros("HORAHASTACICLO1", "Configuracion"));
                return this.strhoraCiclo1Hasta;
            }
            set
            {
                this.strhoraCiclo1Hasta = value;
            }
        }
        public int HoraCiclo2Desde
        {
            get
            {
                this.strhoraCiclo2Desde = int.Parse(Binternacional.Transversal.Util.getlistaParametros("HORADESDECICLO2", "Configuracion"));
                return this.strhoraCiclo2Desde;

            }
            set
            {
                this.strhoraCiclo2Desde = value;
            }
        }
        public int HoraCiclo2Hasta
        {
            get
            {
                this.strhoraCiclo2Hasta = int.Parse(Binternacional.Transversal.Util.getlistaParametros("HORAHASTACICLO2", "Configuracion"));
                return this.strhoraCiclo2Hasta;

            }
            set
            {
                this.strhoraCiclo2Hasta = value;
            }
        }




        /// <summary>
        /// envia el mensaje a las colas MQ y controla la respuesta
        /// </summary>
        /// <param name="strMessage"></param>
        /// <returns></returns>
        public String LlamarServicio(string strMessage, int canal)
        {
            EjecutadoCorrectamente = true;


            try
            {
                byte[] arrDatos = AdjuntarMensaje(strMessage);
                String strRetorno = ConseguirMensaje("OUT_QUEUE", arrDatos).Trim();
                if (!String.IsNullOrEmpty(strRetorno))
                {

                }
                else
                {
                    Console.WriteLine("Excepcion burbujeada 1");
                    EjecutadoCorrectamente = false;
                    strRetorno = ConseguirMensaje("IN_QUEUEE", arrDatos).Trim();
                    if (!String.IsNullOrEmpty(strRetorno))
                        strRetorno = "ERROR: Servicio no responde";

                }
                Binternacional.DTO.ComponenteMQ theComponenteMQ = new DTO.ComponenteMQ();
                theComponenteMQ.Request = strMessage;
                theComponenteMQ.Response = strRetorno;
                theComponenteMQ.TheComponenteCanal.IdCanal = canal;
                theComponenteMQ.TheComponenteTipo.IdComponenteTipo = 3;

                Binternacional.Transversal.Util.insertMensajeMQ(theComponenteMQ);
                return strRetorno;
            }
            catch (Exception ex)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = canal;
                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                theComponente.Mensaje = "LlamarServicio " + ex.Message;
                theComponente.Metodo = "LlamarServicio";


                Binternacional.DTO.ComponenteMQ theComponenteMQ = new DTO.ComponenteMQ();
                theComponenteMQ.Request = strMessage;
                theComponenteMQ.Response = ex.Message;
                theComponenteMQ.TheComponenteCanal.IdCanal = canal;
                theComponenteMQ.TheComponenteTipo.IdComponenteTipo = 3;
                theComponenteMQ.LogException = Binternacional.Transversal.Log.ins_error(theComponente);

                Binternacional.Transversal.Util.insertMensajeMQ(theComponenteMQ);
                return ex.Message;
            }
        }


        private string ConseguirMensaje(string cola, byte[] identificadorMensajeEnCola)
        {
            IBM.WMQ.MQQueueManager objAdministrador = new MQQueueManager(NombreAdministradorColas, Canal, NombreConexion);
            IBM.WMQ.MQQueue objCola = objAdministrador.AccessQueue(cola, IBM.WMQ.MQC.MQOO_INPUT_AS_Q_DEF + IBM.WMQ.MQC.MQOO_FAIL_IF_QUIESCING);
            IBM.WMQ.MQMessage objMensaje = new IBM.WMQ.MQMessage();
            IBM.WMQ.MQGetMessageOptions objOpcionesMensaje = new IBM.WMQ.MQGetMessageOptions();

            objMensaje.Format = IBM.WMQ.MQC.MQFMT_STRING;
            objMensaje.UserId = String.Empty;
            objMensaje.CorrelationId = identificadorMensajeEnCola;

            objOpcionesMensaje.MatchOptions = IBM.WMQ.MQC.MQMO_MATCH_CORREL_ID | IBM.WMQ.MQC.MQMO_MATCH_MSG_ID;
            objOpcionesMensaje.Options = IBM.WMQ.MQC.MQGMO_CONVERT +
                                     IBM.WMQ.MQC.MQGMO_NO_SYNCPOINT +
                                     IBM.WMQ.MQC.MQGMO_WAIT +
                                     IBM.WMQ.MQC.MQGMO_ACCEPT_TRUNCATED_MSG;

            objOpcionesMensaje.WaitInterval = Convert.ToInt32(TiempoEspera.TotalMilliseconds);

            try
            {
                objCola.Get(objMensaje, objOpcionesMensaje);
                return objMensaje.ReadString(objMensaje.MessageLength);

            }
            catch (MQException ex)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                theComponente.Mensaje = "ConseguirMensaje" + ex.Message + " " + ex.CompCode;
                theComponente.Metodo = "ConseguirMensaje";
                Binternacional.Transversal.Log.ins_error(theComponente);
                return String.Empty;
            }
            finally
            {
                if (objCola != null && objCola.IsOpen) objCola.Close();
                if (objAdministrador != null && objAdministrador.IsConnected) objAdministrador.Disconnect();
                if (objAdministrador != null && objAdministrador.IsOpen) objAdministrador.Close();
            }
        }


        private byte[] AdjuntarMensaje(String mensaje)
        {

            try
            {
                MQQueueManager objAdministrador = new MQQueueManager(NombreAdministradorColas, Canal, NombreConexion);
                MQQueue objCola = objAdministrador.AccessQueue("IN_QUEUE",
                                                                MQC.MQOO_OUTPUT +			// open queue for output
                                                                MQC.MQOO_FAIL_IF_QUIESCING);// but not if MQM stopping

                IBM.WMQ.MQMessage objMensaje = new IBM.WMQ.MQMessage();

                objMensaje.Format = MQC.MQFMT_STRING;
                objMensaje.UserId = String.Empty;
                objMensaje.Persistence = MQC.MQPER_PERSISTENT;
                objMensaje.CorrelationId = System.Text.Encoding.UTF8.GetBytes(Guid.NewGuid().ToString().Substring(0, 24));
                objMensaje.DataOffset = 0;

                objMensaje.WriteBytes(mensaje);

                objMensaje.MessageType = MQC.MQMT_DATAGRAM;
                objMensaje.Report = MQC.MQRO_COPY_MSG_ID_TO_CORREL_ID;
                objMensaje.ReplyToQueueName = "OUT_QUEUE";
                objMensaje.ReplyToQueueManagerName = String.Empty;
                objCola.Put(objMensaje);

                return objMensaje.CorrelationId;
            }
            catch (MQException exExcepcion)
            {
                Console.WriteLine("excetion: " + exExcepcion.CompletionCode.ToString());
                //grabar log Base datos modificar condiciones en Colas MQ y ver conexiones
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                theComponente.Mensaje = "AdjuntarMensaje " + exExcepcion.CompletionCode + " " + exExcepcion.Message;
                theComponente.Metodo = "AdjuntarMensaje";
                Binternacional.Transversal.Log.ins_error(theComponente);
                throw exExcepcion;
            }
            catch (Exception ex)
            {
                Console.WriteLine("excetion: " + ex.Message);
                //grabar log Base datos modificar condiciones en Colas MQ y ver conexiones
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                theComponente.Mensaje = "AdjuntarMensaje " + ex.Message + " " + ex.StackTrace;
                theComponente.Metodo = "AdjuntarMensaje";
                Binternacional.Transversal.Log.ins_error(theComponente);
                throw ex;

            }
            finally
            {
                //if (objAdministrador != null)
                //{
                //    objAdministrador.Disconnect();
                //    objAdministrador.Close();
                //}

                //if (objCola != null && objCola.IsOpen)
                //    objCola.Close();
            }
        }



    }
}
