﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Binternacional.Transversal;
using System.Data;

namespace Binternacional.Transversal
{

    /// <summary>
    /// graba las trasas de todas las transacciones Reversas
    /// Comunicacion entre Componente y Flexcube (Colas MQ)
    /// Comunincacion entre Componente y MessageQueue Reversas
    /// Comunicacion entre Componente y Gateway
    /// Graba todas las excepciones relacionadas con los distintos procesos involucrados en el componente(consumo de servicios,BD,colas MQ,MessageQueeu y       Gateway
    ///
    /// </summary>
    public class Log
    {
        /// <summary>
        /// guarda registro de excepciones
        /// </summary>
        /// <param name="theComponente"></param>
        /// <returns></returns>
        public static int ins_error(Binternacional.DTO.Componente theComponente)
        {
            SQLHelper wobjSQLHelper = new SQLHelper();
            int idLog = 0;
            DataTable pobjDataTable = new DataTable();
            try
            {

                wobjSQLHelper.SetParametro("@PidComponente", SqlDbType.Int, 10, theComponente.TheComponenteTipo.IdComponenteTipo);
                wobjSQLHelper.SetParametro("@Pmensaje", SqlDbType.VarChar,5000, theComponente.Mensaje);
                wobjSQLHelper.SetParametro("@PidCanal", SqlDbType.Int, 20, theComponente.TheComponenteCanal.IdCanal);
                wobjSQLHelper.SetParametro("@pmetodo", SqlDbType.VarChar, 50, theComponente.Metodo);

                if (wobjSQLHelper.Ejecutar("ins_log_componente", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        idLog = int.Parse(dtRow["id_log"].ToString());

                    }

                }
                else
                {
                    ///no se logro realizar la insercion en BD
                }

            }

            catch (Exception ex)
            {
                Binternacional.DTO.Componente theComponenteError = new DTO.Componente();

                theComponenteError.TheComponenteCanal.IdCanal = 1;
                theComponenteError.TheComponenteTipo.IdComponenteTipo = 6;
                theComponenteError.Mensaje = ex.Message + " " + ex.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponenteError);
                ///grabar Log BD Generar alerta en Dashboard

            }
            return idLog;
        }
        /// <summary>
        /// guarda registro de las reversas generadas
        /// </summary>
        /// <param name="theComponente"></param>
        /// <returns></returns>
        public static bool ins_reversa(Binternacional.DTO.Reversa theReversa)
        {
            SQLHelper wobjSQLHelper = new SQLHelper();
            bool respuesta = false;
            try
            {

                wobjSQLHelper.SetParametro("@PXREF", SqlDbType.VarChar, 30, theReversa.CodigoTransaccion);
                wobjSQLHelper.SetParametro("@IDESTADO", SqlDbType.VarChar, 30, theReversa.TheReversaEstado.IdEstado);
                wobjSQLHelper.SetParametro("@PTIPOTRANSACCION", SqlDbType.VarChar, 20, theReversa.TheTipoTransaccion.Id);
                wobjSQLHelper.SetParametro("@PCANAL_EJECUCION", SqlDbType.VarChar, 20, theReversa.TheComponenteCanal.IdCanal);
                wobjSQLHelper.SetParametro("@PMENSAJE_REVERSA", SqlDbType.VarChar, 5000, theReversa.Mensaje);

                if (wobjSQLHelper.EjecutarNQ("INS_Reversa", "LOG_TRANSACCIONAL") > 0)
                {
                    respuesta = true;
                }
                else
                {
                    ///no se logro realizar la insercion en BD
                }

            }

            catch (Exception ex)
            {
                ///grabar Log BD Generar alerta en Dashboard

            }
            return respuesta;
        }


        /// <summary>
        /// actualiza estado de la reversa
        /// </summary>
        /// <param name="theReversa"></param>
        /// <returns></returns>
        public static bool upd_reversa(Binternacional.DTO.Reversa theReversa)
        {
            SQLHelper wobjSQLHelper = new SQLHelper();
            bool respuesta = false;
            try
            {

                wobjSQLHelper.SetParametro("@PXREF", SqlDbType.VarChar, 30, theReversa.CodigoTransaccion);
                wobjSQLHelper.SetParametro("@IDESTADO", SqlDbType.VarChar, 30, theReversa.TheReversaEstado.IdEstado);
                wobjSQLHelper.SetParametro("@PTIPOTRANSACCION", SqlDbType.VarChar, 20, theReversa.TheTipoTransaccion.Id);
                wobjSQLHelper.SetParametro("@PCANAL_EJECUCION", SqlDbType.VarChar, 20, theReversa.TheComponenteCanal.IdCanal);

                if (wobjSQLHelper.EjecutarNQ("INS_Reversa", "LOG_TRANSACCIONAL") > 0)
                {
                    respuesta = true;
                }
                else
                {
                    ///no se logro realizar la insercion en BD
                }

            }

            catch (Exception ex)
            {
                ///grabar Log BD Generar alerta en Dashboard

            }
            return respuesta;
        }
    }
}
