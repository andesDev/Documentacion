﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Binternacional.DTO;
using System.Runtime.Caching;
namespace Binternacional.Transversal
{
    /// <summary>
    /// Contiene todas las llamadas a funciones transversales Criptografia ,Helper BD, Comunicacion MQ 
    /// </summary>
    public class Util
    {




        public static string GeneraCorrelativoFCC()
        {
            string millisecond = string.Empty;
            if (DateTime.Now.Millisecond.ToString().Count() == 3)
                millisecond = DateTime.Now.Millisecond.ToString().Substring(0, 2);

            return "IB" + DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month + DateTime.Now.Day + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + millisecond;

        }
        public static void InsLogPagoTarjeta(string pFolioGrupo, string pFolioPago, string pNroCuenta,
                                    string pNroTarjeta, string pRut, string pDv,
                                    string pMonto, string pEstadoEnvio, string pdescripcion)
        {
            SQLHelper wobjSQLHelper = new SQLHelper();

            try
            {

                wobjSQLHelper.SetParametro("@pFolioGrupo", SqlDbType.VarChar, 30, pFolioGrupo);
                wobjSQLHelper.SetParametro("@pFolioPago", SqlDbType.VarChar, 30, pFolioPago);
                wobjSQLHelper.SetParametro("@pNroCuenta", SqlDbType.VarChar, 20, pNroCuenta);
                wobjSQLHelper.SetParametro("@pNroTarjeta", SqlDbType.VarChar, 20, pNroTarjeta);
                wobjSQLHelper.SetParametro("@pRut", SqlDbType.VarChar, 10, pRut);
                wobjSQLHelper.SetParametro("@pDV", SqlDbType.VarChar, 1, pDv);
                wobjSQLHelper.SetParametro("@pMonto", SqlDbType.VarChar, 20, pMonto);
                wobjSQLHelper.SetParametro("@pEstadoEnvio", SqlDbType.VarChar, 1, pEstadoEnvio);
                wobjSQLHelper.SetParametro("@pDescripcion", SqlDbType.VarChar, 5000, pdescripcion);

                switch (wobjSQLHelper.EjecutarNQ("INS_PagoTarjeta", "KTF"))
                {
                    case 0:
                        ///grabar Log BD Generar alerta en Dashboard
                        throw new Exception("No se pudo grabar el Log de Pago de Tarjeta de Credito");
                }
                //====================================================================================
            }

            catch (Exception ex)
            {
                ///grabar Log BD Generar alerta en Dashboard

            }
        }

        public static string GetConsultaDescripcion(string pConcepto, string pCodigo, DataTable pobjDataTable)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();


            try
            {
                //Seteo Parámetros.
                //====================================================================================

                wobjSQLHelper.SetParametro("@Concepto",
                                           SqlDbType.VarChar,
                                           20,
                                           pConcepto);

                wobjSQLHelper.SetParametro("@Codigo",
                                          SqlDbType.VarChar,
                                          20,
                                          pCodigo);
                //====================================================================================


                //Ejecuto SP.
                //====================================================================================
                if (wobjSQLHelper.Ejecutar("wp_parametro_get_by_codigo_and_concepto",
                                           "KTF",
                                           pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        parametro = dtRow["descripcion"].ToString();
                    }

                }


                //====================================================================================
            }

            #region Catch

            catch (Exception eobjException)
            {
                throw eobjException;
            }
            #endregion

            return parametro;
        }


        public static void insertParametro(Parametro theParametro)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();


            try
            {

                wobjSQLHelper.SetParametro("@pidgrupo", SqlDbType.Int, 20, theParametro.TheParametroGrupo.IdGrupo);
                wobjSQLHelper.SetParametro("@pcodigo", SqlDbType.VarChar, 50, theParametro.Codigo);
                wobjSQLHelper.SetParametro("@pdescripcion", SqlDbType.VarChar, 100, theParametro.Descripcion);
                wobjSQLHelper.SetParametro("@pmensaje", SqlDbType.VarChar, 5000, theParametro.Mensaje);
                wobjSQLHelper.SetParametro("@pusuarioingreso", SqlDbType.VarChar, 50, theParametro.UsuarioIngreso);
                wobjSQLHelper.SetParametro("@reversa", SqlDbType.Int, 10, theParametro.Reversa);



                if (wobjSQLHelper.EjecutarNQ("INS_parametro", "LOG_TRANSACCIONAL") <= 0)
                { }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }

        }

        /// <summary>
        /// inserta la salida y entrada obtenida con su interaccion con el core
        /// </summary>
        /// <param name="theParametro"></param>
        public static void insertMensajeMQ(ComponenteMQ theComponenteMQ)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();


            try
            {

                wobjSQLHelper.SetParametro("@prequest", SqlDbType.VarChar, 5000, theComponenteMQ.Request);
                wobjSQLHelper.SetParametro("@presponse", SqlDbType.VarChar, 5000, theComponenteMQ.Response);
                wobjSQLHelper.SetParametro("@pcanal", SqlDbType.Int, 10, theComponenteMQ.TheComponenteCanal.IdCanal);
                wobjSQLHelper.SetParametro("@ptipoTransaccion", SqlDbType.Int, 10, theComponenteMQ.TheComponenteTipo.IdComponenteTipo);
                wobjSQLHelper.SetParametro("@idLog", SqlDbType.Int, 10, theComponenteMQ.LogException);
                if (wobjSQLHelper.EjecutarNQ("INS_LogMQ", "LOG_TRANSACCIONAL") <= 0)
                { }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }

        }

        public static void insertParametroGrupo(ParametroGrupo theParametroGrupo)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();


            try
            {

                wobjSQLHelper.SetParametro("@pdescripcion", SqlDbType.VarChar, 100, theParametroGrupo.Descripcion);
                wobjSQLHelper.SetParametro("@pusuarioingreso", SqlDbType.VarChar, 50, theParametroGrupo.UsuarioIngreso);


                if (wobjSQLHelper.EjecutarNQ("INS_parametro_grupo", "LOG_TRANSACCIONAL") <= 0)
                { }

            }


            catch (Exception eobjException)
            {

                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }

        }


        public static string getlistaParametros(string codigo, string grupo)
        {
            DataTable pobjDataTable = new DataTable();
            SQLHelper wobjSQLHelper = new SQLHelper();
            List<Parametro> collParametros = new List<Parametro>();
            Parametro theParametro = new Parametro();
            try
            {

                var cache = MemoryCache.Default;
                var policy = new CacheItemPolicy();
                /// se modifica duracion de chache servidor desde Front END
                // policy.AbsoluteExpiration = Convert.ToDateTime(Util.getParametro("CacheServicio"));
                policy.SlidingExpiration = TimeSpan.FromSeconds(3000);
                ///se agrega valor de servicio en cache


                ///carga estructura de parametros al momento de Refrescarse configuracion desde Front End
                if (cache.Get("Parametrizacion") == null)
                {
                    if (wobjSQLHelper.Ejecutar("GET_parametro_transacciones", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                    {
                        foreach (DataRow dtRow in pobjDataTable.Rows)
                        {
                            theParametro = new Parametro();
                            theParametro.Codigo = dtRow["codigo"].ToString();
                            theParametro.TheParametroGrupo.Descripcion = dtRow["descripcion_grupo"].ToString();
                            theParametro.Mensaje = dtRow["mensaje"].ToString();
                            collParametros.Add(theParametro);
                        }

                    }
                    cache.Set("Parametrizacion", collParametros, policy.AbsoluteExpiration);

                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                    theComponente.Mensaje = "Obtiene Parametrizacion General desde Base de Datos";
                    theComponente.Metodo = "getlistaParametros";
                    Binternacional.Transversal.Log.ins_error(theComponente);

                }
                else
                {
                    ///se parametriza cache con lista de estructuras
                    collParametros = cache["Parametrizacion"] as List<Parametro>;
                    collParametros = collParametros.Where(x => x.Codigo == codigo && x.TheParametroGrupo.Descripcion == grupo).ToList();

                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                    theComponente.Mensaje = "Obtiene Parametrizacion General desde Cache";
                    theComponente.Metodo = "getlistaParametros";
                    Binternacional.Transversal.Log.ins_error(theComponente);
                }
            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;
                theComponente.Metodo = "getlistaParametros";
                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            return collParametros.First().Mensaje;
        }



        /// <summary>
        /// inserta un nuevo canal de comunicacion 
        /// </summary>
        /// <param name="theComponenteCanal"></param>
        public static void insertCanal(ComponenteCanal theComponenteCanal)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();

            try
            {
                wobjSQLHelper.SetParametro("@pdescripcion", SqlDbType.VarChar, 100, theComponenteCanal.Descripcion);
                wobjSQLHelper.SetParametro("@pusuarioIngreso", SqlDbType.VarChar, 50, theComponenteCanal.UsuarioIngreso);
                wobjSQLHelper.SetParametro("@pToken", SqlDbType.VarChar, 500, Binternacional.Transversal.Seguridad.Encriptacion(theComponenteCanal.Token, "bancoInternacional", "EncriptacionToken", "MD5", 5, "1234567891234567", 256));

                if (wobjSQLHelper.EjecutarNQ("INS_canal_ejecucion", "LOG_TRANSACCIONAL") <= 0)
                {
                }

            }


            catch (Exception eobjException)
            {

                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }

        }

        /// <summary>
        /// retorna los canales disponibles para realizar transacciones
        /// </summary>
        /// <returns></returns>
        public static List<ComponenteCanal> getCanales()
        {
            DataTable pobjDataTable = new DataTable();
            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();
            List<ComponenteCanal> collCanales = new List<ComponenteCanal>();
            ComponenteCanal theComponenteCanal;
            try
            {


                if (wobjSQLHelper.Ejecutar("GET_canal_ejecucion", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        theComponenteCanal = new ComponenteCanal();
                        theComponenteCanal.Descripcion = !string.IsNullOrEmpty(dtRow["descripcion"].ToString()) ? dtRow["descripcion"].ToString() : string.Empty;
                        theComponenteCanal.UsuarioIngreso = !string.IsNullOrEmpty(dtRow["usuario_ingreso"].ToString()) ? dtRow["usuario_ingreso"].ToString() : string.Empty;
                        theComponenteCanal.FechaIngreso = !string.IsNullOrEmpty(dtRow["fecha_ingreso"].ToString()) ? DateTime.Parse(dtRow["fecha_ingreso"].ToString()) : DateTime.MinValue;
                        theComponenteCanal.Token = !string.IsNullOrEmpty(dtRow["token"].ToString()) ? dtRow["token"].ToString() : string.Empty;

                        collCanales.Add(theComponenteCanal);
                    }

                }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            return collCanales;
        }


        public static bool validaToken(string token)
        {
            DataTable pobjDataTable = new DataTable();
            bool retorno = false;
            SQLHelper wobjSQLHelper = new SQLHelper();

            try
            {
                wobjSQLHelper.SetParametro("@pToken", SqlDbType.VarChar, 500, token);
                if (wobjSQLHelper.Ejecutar("GET_valida_token", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    retorno = true;
                }

            }
            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            return retorno;
        }
        public static List<Reversa> getReversas()
        {
            DataTable pobjDataTable = new DataTable();
            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();
            List<Reversa> collReversas = new List<Reversa>();
            Reversa theReversa;
            try
            {


                if (wobjSQLHelper.Ejecutar("transaccional_select_reversa", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        theReversa = new Reversa();
                        theReversa.IdReversa = int.Parse(dtRow["id_reversa"].ToString());
                        theReversa.FechaRecepcionMensaje = DateTime.Parse(dtRow["FECHA_RECEPCION_MENSAJE"].ToString());
                        theReversa.TheReversaEstado.Descripcion = dtRow["ESTADO_REVERSA"].ToString();
                        theReversa.TheTipoTransaccion.Descripcion = dtRow["TIPO_REVERSA"].ToString();
                        theReversa.NumeroIntentos = int.Parse(dtRow["NUMERO_INTENTOS"].ToString());
                        theReversa.TheComponenteCanal.Descripcion = dtRow["CANAL"].ToString();
                        collReversas.Add(theReversa);
                    }

                }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            return collReversas;
        }
        public static List<Parametro> getParametro()
        {
            DataTable pobjDataTable = new DataTable();
            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();
            List<Parametro> collParametros = new List<Parametro>();
            Parametro theParametro;
            try
            {


                if (wobjSQLHelper.Ejecutar("GET_parametro", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        theParametro = new Parametro();
                        theParametro.Codigo = dtRow["codigo"].ToString();
                        theParametro.Descripcion = dtRow["descripcion"].ToString();
                        theParametro.Mensaje = dtRow["mensaje"].ToString();
                        theParametro.UsuarioIngreso = dtRow["usuario_ingreso"].ToString();
                        theParametro.FechaIngreso = DateTime.Parse(dtRow["fecha_ingreso"].ToString());
                        theParametro.TheParametroGrupo.Descripcion = dtRow["tipoParametro"].ToString();
                        collParametros.Add(theParametro);
                    }

                }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 6;
                theComponente.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            return collParametros;
        }
        public static List<Componente> getComponenteError()
        {
            DataTable pobjDataTable = new DataTable();
            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();
            List<Componente> collComponente = new List<Componente>();
            Componente theComponente;
            try
            {


                if (wobjSQLHelper.Ejecutar("transaccional_select_errores", "LOG_TRANSACCIONAL", pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        theComponente = new Componente();
                        theComponente.FechaException = DateTime.Parse(dtRow["fecha_exception"].ToString());
                        theComponente.Mensaje = dtRow["message_exception"].ToString();

                        theComponente.TheComponenteTipo.Descripcion = dtRow["origen_error"].ToString();
                        theComponente.TheComponenteCanal.Descripcion = dtRow["canal"].ToString();
                        collComponente.Add(theComponente);
                    }

                }

            }


            catch (Exception eobjException)
            {
                Binternacional.DTO.Componente theComponenteException = new DTO.Componente();

                theComponenteException.TheComponenteCanal.IdCanal = 1;
                theComponenteException.TheComponenteTipo.IdComponenteTipo = 6;
                theComponenteException.Mensaje = eobjException.Message + " " + eobjException.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponenteException);
            }
            return collComponente;
        }

    }
}
