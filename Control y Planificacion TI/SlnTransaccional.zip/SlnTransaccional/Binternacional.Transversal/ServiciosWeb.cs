﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Binternacional.Transversal.WSpagoCredito;
using Binternacional.DTO;

namespace Binternacional.Transversal
{
    public class ServiciosWeb
    {
         
        /// <summary>
        /// obtiene fecha Flexcube
        /// </summary>
        /// <returns></returns>
        public static int ObtieneFechaCore()
        {
            WsObtieneFechaCore.Service1SoapClient service = new WsObtieneFechaCore.Service1SoapClient();
            XmlDocument response = new XmlDocument();
            int fechaCore = 0;

            try
            {
                service.Open();

                response.LoadXml(service.ObtieneFechaFCC());

                if (response.SelectSingleNode("KTF_Response").HasChildNodes)
                {
                    XmlNode xmlUsuario = response.SelectSingleNode("KTF_Response/FechasFCC");
                    fechaCore = int.Parse(xmlUsuario.SelectSingleNode("DIA_CONTABLE").InnerText);

                }

            }
            catch (Exception ex)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 4;
                theComponente.Mensaje = ex.Message + "Url Servicio " + service.Endpoint.ListenUri;

                Binternacional.Transversal.Log.ins_error(theComponente);
                ///Grabar Log de Servicio
            }
            finally
            {
                service.Close();
            }
            return fechaCore;
        }
        public static int ObtieneHoraCore()
        {
            WsObtieneFechaCore.Service1SoapClient service = new WsObtieneFechaCore.Service1SoapClient();
            XmlDocument response = new XmlDocument();
            int HoraCore = 0;

            try
            {
                service.Open();

                response.LoadXml(service.ObtieneFechaFCC());

                if (response.SelectSingleNode("KTF_Response").HasChildNodes)
                {
                    XmlNode xmlUsuario = response.SelectSingleNode("KTF_Response/FechasFCC");
                    HoraCore = int.Parse(xmlUsuario.SelectSingleNode("HORA").InnerText);

                }

            }
            catch (Exception ex)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 4;
                theComponente.Mensaje = ex.Message + "Url Servicio " + service.Endpoint.ListenUri;

                Binternacional.Transversal.Log.ins_error(theComponente);
                ///Grabar Log de Servicio
            }
            finally
            {
                service.Close();
            }
            return HoraCore;
        }
        /// <summary>
        /// realiza pago de tarjeta Credito
        /// </summary>
        /// <returns></returns>
        public static int PagoTarjeta(Transaccion theTransaccion)
        {
            int contador = 0;
            int resultado = 0;
            Binternacional.DTO.Componente theComponente = new DTO.Componente();
            try
            {
                WsPagoTarjeta.PagoTarjetasSoapClient service = new WsPagoTarjeta.PagoTarjetasSoapClient();
                WsPagoTarjeta.RETORNO wobjM_Cliente_XML = new WsPagoTarjeta.RETORNO();

                service.Open();
                WsPagoTarjeta.SAT_PAGO_ONLINE wobj = new WsPagoTarjeta.SAT_PAGO_ONLINE();
                wobj.FOLIO = Util.GeneraCorrelativoFCC();

                WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE[] wobjDetalle = new WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE[9];
                wobjDetalle[contador] = new WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE();

                foreach (var item in theTransaccion.TheTarjetaCredito.CollTarjetaCredito)
                {
                    wobjDetalle[contador].TDROL_ID = Util.GeneraCorrelativoFCC();
                    wobjDetalle[contador].MONTO = theTransaccion.MontoTransaccion;
                    wobjDetalle[contador].NUM_CUENTA = theTransaccion.TheTarjetaCredito.NumeroCuenta;
                    wobjDetalle[contador].NUM_TARJETA = theTransaccion.TheTarjetaCredito.NumeroTarjeta;
                    wobjDetalle[contador].RUT = "13928597";// theTransaccion.RutCliente.Substring(theTransaccion.RutCliente.Length - 1, theTransaccion.RutCliente.Length);
                    wobjDetalle[contador].DV = "2";// theTransaccion.RutCliente.Substring(theTransaccion.RutCliente.Length - 1, 1);

                }

                wobj.PAGOS_ONLINE_DETALLE = wobjDetalle;

                wobjM_Cliente_XML = service.PAGO_ONLINE(wobj);

                //if (!wobjM_Cliente_XML.ESTADO)
                //{

                //    Util.InsLogPagoTarjeta(wobj.FOLIO, wobjDetalle[contador].TDROL_ID, wobjDetalle[contador].NUM_CUENTA,
                //                              wobjDetalle[contador].NUM_TARJETA, wobjDetalle[contador].RUT,
                //                              wobjDetalle[contador].DV, wobjDetalle[contador].MONTO, "E", wobjM_Cliente_XML.DESCRIPCION);
                //    response = false;
                //}


                //else
                //{
                //    Util.InsLogPagoTarjeta(wobj.FOLIO, wobjDetalle[contador].TDROL_ID, wobjDetalle[contador].NUM_CUENTA,
                //                            wobjDetalle[contador].NUM_TARJETA, wobjDetalle[contador].RUT,
                //                            wobjDetalle[contador].DV, wobjDetalle[contador].MONTO, "T", wobjM_Cliente_XML.DESCRIPCION);
                //    response = true;
                //}
                service.Close();

            }
            catch (Exception ex)
            {
                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 4;
                theComponente.Mensaje = ex.Message + " " + ex.StackTrace;
                theComponente.Metodo = "PagoTarjeta";
              
                resultado= Binternacional.Transversal.Log.ins_error(theComponente);


                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 4;
                theComponente.Mensaje ="ID resultado error"+ resultado;
                theComponente.Metodo = "PagoTarjeta";
                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            finally
            {

            }


            return resultado;
        }

        /// <summary>
        /// realiza cuota pago Leasing
        /// </summary>
        /// <returns></returns>
        public static bool PagoCuotaLeasing(Transaccion theTransaccion)
        {
            bool response = false;
            WsPagoLeasing.PagosEnLineaClient service = new WsPagoLeasing.PagosEnLineaClient();
            WsPagoLeasing.respPagarEnLinea respuesta = new WsPagoLeasing.respPagarEnLinea();

            try
            {

                service.Open();

                WsPagoLeasing.datosHeaderRequest cabezera = new WsPagoLeasing.datosHeaderRequest();
                //Cabezera servicio
                cabezera.transaccion.fechaHora = DateTime.Now;
                cabezera.transaccion.idTransaccionNegocio = "PX000148_PagosEnLinea";
                cabezera.transaccion.idTransaccionOSB = "PX000148_PagosEnLinea";
                cabezera.transaccion.sistema = "IB";
                cabezera.transaccion.sucursal = "001";
                cabezera.transaccion.usuario = "60558485";

                WsPagoLeasing.reqPagarEnLinea request = new WsPagoLeasing.reqPagarEnLinea();

                request.cuentaCorrienteDeCargo = theTransaccion.NumeroCuentaOrigen;
                request.fechaVencimiento = DateTime.Parse(theTransaccion.TheLeasing.FechaVencimiento);
                request.montoCancelar = float.Parse(theTransaccion.MontoTransaccion);
                request.numeroInternetBanking = 0;
                request.numeroOperacion = int.Parse(theTransaccion.TheLeasing.NumeroOperacion);
                request.rutCliente = int.Parse(theTransaccion.RutCliente);

                WsPagoLeasing.datosHeaderResponse resultado = new WsPagoLeasing.datosHeaderResponse();
                resultado = service.PagarEnLinea(cabezera, request, out respuesta);
                string valor = respuesta.PagosEnLineaResult[0].Resultado;
                response = true;
            }
            catch (Exception ex)
            {

                ///grabar Log 
            }
            finally
            {

                service.Close();
            }
            return response;
        }

        /// <summary>
        /// realiza pago cuota credito Consumo
        /// </summary>
        /// <returns></returns>
        public static bool PagoCuotaCreditoConsumo()
        {

            bool response = false;
            WSpagoCredito.CreaPagoOperacionCreditoClient service = new CreaPagoOperacionCreditoClient();
            WSpagoCredito.respCrearPagoOperacionCredito respuesta = new respCrearPagoOperacionCredito();


            try
            {

                service.Open();

                WSpagoCredito.datosHeaderRequest cabezera = new datosHeaderRequest();
                //Cabezera servicio
                cabezera.transaccion.fechaHora = DateTime.Now;
                cabezera.transaccion.idTransaccionNegocio = "";
                cabezera.transaccion.idTransaccionOSB = "";
                cabezera.transaccion.sistema = "";
                cabezera.transaccion.sucursal = "";
                cabezera.transaccion.usuario = "";

                WSpagoCredito.reqCrearPagoOperacionCredito request = new reqCrearPagoOperacionCredito();

                request.SCODE = "";
                request.XREF = "";
                request.TXNBRN = "";
                request.ACCNO = "";
                request.BRN = "";
                request.ALTACCNO = "";
                request.VALDT = "";
                request.EXECDT = "";
                request.LIMITDT = "";
                request.AUTHSTAT = "A";

                PMNTDETType DetallePago = new PMNTDETType();

                DetallePago.PMNTMODE = "ACC";
                DetallePago.STTLCCY = "";
                DetallePago.AMTSTTL = "";
                DetallePago.STTLBRN = "";
                DetallePago.STTLACC = "";

                request.PMNTDET = new PMNTDETType[1];

                request.PMNTDET[0] = DetallePago;

                WSpagoCredito.datosHeaderResponse resultado = new datosHeaderResponse();

                resultado = service.CrearPagoOperacionCredito(cabezera, request, out respuesta);
                //string valor = respuesta.[0].Resultado;
                response = true;
            }
            catch (Exception ex)
            {

                ///grabar Log 
            }
            finally
            {

                service.Close();
            }
            return response;
        }


        public static bool PagoGastoCobranzaCreditoConsumo()
        {

            bool response = false;
            WSpagoCredito.CreaPagoOperacionCreditoClient service = new CreaPagoOperacionCreditoClient();
            WSpagoCredito.respCrearPagoOperacionCredito respuesta = new respCrearPagoOperacionCredito();


            try
            {

                service.Open();

                WSpagoCredito.datosHeaderRequest cabezera = new datosHeaderRequest();
                //Cabezera servicio
                cabezera.transaccion.fechaHora = DateTime.Now;
                cabezera.transaccion.idTransaccionNegocio = "";
                cabezera.transaccion.idTransaccionOSB = "";
                cabezera.transaccion.sistema = "";
                cabezera.transaccion.sucursal = "";
                cabezera.transaccion.usuario = "";

                WSpagoCredito.reqCrearPagoOperacionCredito request = new reqCrearPagoOperacionCredito();

                request.SCODE = "";
                request.XREF = "";
                request.TXNBRN = "";
                request.ACCNO = "";
                request.BRN = "";
                request.ALTACCNO = "";
                request.VALDT = "";
                request.EXECDT = "";
                request.LIMITDT = "";
                request.AUTHSTAT = "A";

                PMNTDETType DetallePago = new PMNTDETType();

                DetallePago.PMNTMODE = "ACC";
                DetallePago.STTLCCY = "";
                DetallePago.AMTSTTL = "";
                DetallePago.STTLBRN = "";
                DetallePago.STTLACC = "";

                request.PMNTDET = new PMNTDETType[1];

                request.PMNTDET[0] = DetallePago;

                WSpagoCredito.datosHeaderResponse resultado = new datosHeaderResponse();

                resultado = service.CrearPagoOperacionCredito(cabezera, request, out respuesta);
                //string valor = respuesta.[0].Resultado;
                response = true;
            }
            catch (Exception ex)
            {

                ///grabar Log 
            }
            finally
            {

                service.Close();
            }
            return response;
        }
    }

}

