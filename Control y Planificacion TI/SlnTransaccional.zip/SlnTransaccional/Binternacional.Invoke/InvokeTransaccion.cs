﻿using System;
using System.Collections.Generic;
using System.Text;
using Binternacional.DTO;
using System.Xml;
using System.Threading;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Binternacional.Invoke
{
    public class InvokeTransaccion
    {
        /// <summary>
        /// carga estructura XML de transaccion a ajecutar en flexcube esta dependera del tipo de transacion ejecutada por cliente
        /// </summary>
        /// <param name="tipoTransaccion"></param>
        /// <returns></returns>
        public static XmlDocument LoadEstructuraTransaccion(string codigoProducto)
        {
            XmlDocument documento = new XmlDocument();
            ///realiza carga de producto Parametrico

            string estructura = Binternacional.Transversal.Util.getlistaParametros(codigoProducto, "Transacciones");
            if (!string.IsNullOrEmpty(estructura))
                documento.LoadXml(estructura);

            return documento;
        }


        /// <summary>
        /// valida parametros de entrada basicos para realizar cargo a core
        /// </summary>
        /// <param name="TheTransaccion"></param>
        /// <returns></returns>
        protected bool validarParametrosTransaccion(Transaccion TheTransaccion)
        {
            bool retorno = false;
            if (!string.IsNullOrEmpty(TheTransaccion.Scode) && !string.IsNullOrEmpty(TheTransaccion.Sucursal) && !string.IsNullOrEmpty(TheTransaccion.Producto) && !string.IsNullOrEmpty(TheTransaccion.Moneda) && !string.IsNullOrEmpty(TheTransaccion.NumeroCuentaOrigen))
                retorno = true;
            else
                retorno = false;

            return retorno;


        }
        /// <summary>
        /// Ejecuta Mensaje de transaccion
        /// </summary>
        /// <param name="mensaje"></param>
        public RespuestaTransaccion ejecutarTransaccion(Transaccion TheTransaccion)
        {
            Binternacional.DTO.RespuestaTransaccion theRespuestaTransaccion = new Binternacional.DTO.RespuestaTransaccion();
            XmlDocument reversa = new XmlDocument();
            int resultado = 0;
            try
            {
                if (TheTransaccion.TheComponenteCanal != null)
                {
                    ///valida ingreso de token de seguridad
                    if (!string.IsNullOrEmpty(TheTransaccion.TheComponenteCanal.Token))
                    {
                        ///valida que codigo token sea correcto
                        if (Binternacional.Transversal.Util.validaToken(TheTransaccion.TheComponenteCanal.Token))
                        {
                            ///validar todos los datos necesarios para el cargo
                            if (validarParametrosTransaccion(TheTransaccion))
                            {


                                Binternacional.MQ.MQ theMq = new MQ.MQ();

                                ///Carga estructura para realizar el cargo a Core
                                XmlDocument documento = LoadEstructuraTransaccion(TheTransaccion.Producto);


                                if (!string.IsNullOrEmpty(documento.InnerXml))
                                {
                                    XmlDocument respuesta = new XmlDocument();


                                    string correlativo = Binternacional.Transversal.Util.GeneraCorrelativoFCC();
                                    ///asignacion de parametros necesarios para realizar cargo
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/SCODE").InnerXml = TheTransaccion.Scode;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/XREF").InnerXml = correlativo;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/BRN").InnerXml = TheTransaccion.Sucursal;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/PRD").InnerXml = TheTransaccion.Producto;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNDATE").InnerXml = theMq.FechaCore.ToString();
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNCCY").InnerXml = TheTransaccion.Moneda;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNAMT").InnerXml = TheTransaccion.MontoTransaccion;
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNBRN").InnerXml = TheTransaccion.Sucursal;

                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNACC").InnerXml = TheTransaccion.NumeroCuentaOrigen.ToString();
                                    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/AUTHSTAT").InnerXml = "A";


                                    if (TheTransaccion.Producto == "ILAC" || TheTransaccion.Producto == "ICTE" || TheTransaccion.Producto == "IBCO" || TheTransaccion.Producto == "IBTG" || TheTransaccion.Producto == "IBSP")
                                    {
                                        ///validacion de parametros validos para realizar cargos en legados
                                        documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETCCY").InnerXml = TheTransaccion.Moneda;
                                        documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETAMT").InnerXml = TheTransaccion.MontoTransaccion;
                                        documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETACCBRN").InnerXml = TheTransaccion.Sucursal;
                                        documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETACC").InnerXml = TheTransaccion.NumeroCuentaDestino.ToString();

                                    }
                                    if (TheTransaccion.Producto == "TEFC")
                                    {
                                        documento.SelectNodes("FCCRT/UPLOAD_RTL_TELLERTXN/UDFDETAILS/FIELD_NAME")[0].InnerXml = "DATA_ORIGEN";
                                        documento.SelectNodes("FCCRT/UPLOAD_RTL_TELLERTXN/UDFDETAILS/FIELD_VALUE")[0].InnerXml = "11111222ddd2222fff22222";


                                        documento.SelectNodes("FCCRT/UPLOAD_RTL_TELLERTXN/UDFDETAILS/FIELD_NAME")[1].InnerXml = "DATA_DESTINO";
                                        documento.SelectNodes("FCCRT/UPLOAD_RTL_TELLERTXN/UDFDETAILS/FIELD_VALUE")[1].InnerXml = "11111222ddd2222fff22222";


                                    }

                                    Thread mobjDebitoCoreThread = null;

                                    mobjDebitoCoreThread = new Thread(delegate()
                                    {
                                        try
                                        {
                                            string filtroRetornoTeller = theMq.LlamarServicio(documento.InnerXml, TheTransaccion.TheComponenteCanal.IdCanal).Substring(documento.InnerXml.IndexOf("<FCCRT>"));
                                            string valor = "<?xml version='1.0' encoding='UTF-8'?>" + "" + filtroRetornoTeller.Substring(filtroRetornoTeller.IndexOf("<FCCRT>")).Trim();
                                            respuesta.LoadXml(valor);
                                        }

                                        catch (Exception eobjException)
                                        {
                                            Binternacional.DTO.Componente theComponente = new Componente();
                                            theComponente.TheComponenteCanal.IdCanal = 1;
                                            theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                                            theComponente.Mensaje = eobjException.Message + eobjException.StackTrace;
                                            theComponente.Metodo = "Reversa Core";
                                        }
                                    }
                                                 );

                                    mobjDebitoCoreThread.Start();

                                    //Espero. Si no termina antes del timeout aborto y encolo reversa.
                                    if (!mobjDebitoCoreThread.Join(int.Parse(Binternacional.Transversal.Util.getlistaParametros("TimeOutCore", "Configuracion"))))
                                    {
                                        ///Aborta transaccion si no es exitosa dentro de los segundos configurados
                                        mobjDebitoCoreThread.Abort();

                                        ///estructura de reversa
                                        reversa.LoadXml(Binternacional.Transversal.Util.getlistaParametros("reversaCore", "Transacciones"));

                                        reversa.SelectSingleNode("FCCRT/UPLOAD_RTL_REVERSE/SCODE").InnerXml = TheTransaccion.Scode;
                                        reversa.SelectSingleNode("FCCRT/UPLOAD_RTL_REVERSE/XREF").InnerXml = correlativo;


                                        respuesta.LoadXml(theMq.LlamarServicio(reversa.InnerXml, TheTransaccion.TheComponenteCanal.IdCanal).Substring(documento.InnerXml.IndexOf("<FCCRT>")));
                                    }

                                    if (respuesta.InnerXml.Contains("ERROR_RTL_TELLERTXN"))
                                    {
                                        /// si el error no es un timeout el cargo no fue realizado por lo que no se debe ejecutar una reversa
                                        theRespuestaTransaccion.Mensaje = respuesta.SelectSingleNode("FCCRT/ERROR_RTL_TELLERTXN/ERROR/EDESC").InnerText;
                                        theRespuestaTransaccion.Codigo = respuesta.SelectSingleNode("FCCRT/ERROR_RTL_TELLERTXN/ERROR/ECODE").InnerText;
                                        theRespuestaTransaccion.Xref = respuesta.SelectSingleNode("FCCRT/ERROR_RTL_TELLERTXN/XREF").InnerText;
                                        theRespuestaTransaccion.Respuesta = respuesta.InnerXml;

                                    }
                                    else
                                    {
                                        //si el cargo al Core es correcto evaluar el productos y Sigue el flujo
                                        if (TheTransaccion.Producto == "PTCR")
                                        {
                                            resultado = Binternacional.Transversal.ServiciosWeb.PagoTarjeta(TheTransaccion);

                                            //respuesta correcta
                                            if (resultado.Equals(0))
                                            {
                                                /// transaccion realizada de forma exitosa
                                                theRespuestaTransaccion.FccRef = respuesta.SelectSingleNode("FCCRT/REPLY_RTL_TELLERTXN/RTDETAILS/FCCREF").InnerText;
                                                theRespuestaTransaccion.Xref = respuesta.SelectSingleNode("FCCRT/REPLY_RTL_TELLERTXN/XREF").InnerText;
                                                theRespuestaTransaccion.Codigo = "00";
                                                theRespuestaTransaccion.Mensaje = "Transaccion Realizada de forma exitosa";
                                                theRespuestaTransaccion.Respuesta = respuesta.InnerXml;

                                            }
                                            else
                                            {
                                                Binternacional.DTO.Componente theComponente = new Componente();
                                                theComponente.TheComponenteCanal.IdCanal = 1;
                                                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                                                theComponente.Mensaje = "Pago tarjeta Incorrecto procede a reversar";
                                                theComponente.Metodo = reversa.InnerXml;

                                                Binternacional.Transversal.Log.ins_error(theComponente);

                                                //se realiza reversa
                                                reversa.LoadXml(Binternacional.Transversal.Util.getlistaParametros("reversaCore","Transacciones"));

                                                reversa.SelectSingleNode("FCCRT/UPLOAD_RTL_REVERSE/SCODE").InnerXml = TheTransaccion.Scode;
                                                reversa.SelectSingleNode("FCCRT/UPLOAD_RTL_REVERSE/XREF").InnerXml = correlativo;

                                                try
                                                {
                                                    string filtroRetornoTellerReversa = theMq.LlamarServicio(reversa.InnerXml, TheTransaccion.TheComponenteCanal.IdCanal).Substring(documento.InnerXml.IndexOf("<FCCRT>"));


                                                    theComponente.TheComponenteCanal.IdCanal = 1;
                                                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                                                    theComponente.Mensaje = "cargo XML de reversa exitosamente";
                                                    theComponente.Metodo = respuesta.InnerXml;

                                                    Binternacional.Transversal.Log.ins_error(theComponente);

                                                    string valor = "<?xml version='1.0' encoding='UTF-8'?>" + "" + filtroRetornoTellerReversa.Substring(filtroRetornoTellerReversa.IndexOf("<FCCRT>")).Trim();
                                                    respuesta.LoadXml(valor);


                                                    theComponente.TheComponenteCanal.IdCanal = 1;
                                                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                                                    theComponente.Mensaje = "cargo XML de reversa exitosamente";
                                                    theComponente.Metodo = "HOLA2";

                                                    Binternacional.Transversal.Log.ins_error(theComponente);

                                                }
                                                catch (Exception ex)
                                                {


                                                    theComponente.TheComponenteCanal.IdCanal = 1;
                                                    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                                                    theComponente.Mensaje = ex.Message + ex.StackTrace;
                                                    theComponente.Metodo = "HOLA1";

                                                    Binternacional.Transversal.Log.ins_error(theComponente);

                                                }
                                            }

                                        }

                                        if (TheTransaccion.Producto == "IPLE")
                                        {
                                            Binternacional.Transversal.ServiciosWeb.PagoCuotaLeasing(TheTransaccion);


                                            ComponenteMQ theComponenteMQ = new ComponenteMQ();
                                            theComponenteMQ.FechaTransaccion = DateTime.Now;
                                            theComponenteMQ.Request = documento.InnerXml;
                                            theComponenteMQ.TheComponenteTipo.Descripcion = "reversa Core Pago leasing";
                                            theComponenteMQ.TheComponenteCanal.IdCanal = 1;

                                            Binternacional.MessageQueue.Mensajeria.EnvioMensajeMessageQueue(theComponenteMQ);

                                            ///si falla pago Leasing se reversa el cargo y se informa Alerta y Legado
                                        }
                                        if (TheTransaccion.Producto == "PTCR")
                                        {
                                            //Binternacional.Transversal.ServiciosWeb.PagoCuotaCreditoConsumo();
                                            //Binternacional.Transversal.ServiciosWeb.PagoGastoCobranzaCreditoConsumo();

                                            ///si falla pago Credito Consumo se reversa el cargo y se informa Alerta y Legado
                                            ///
                                            ComponenteMQ theComponenteMQ = new ComponenteMQ();
                                            theComponenteMQ.FechaTransaccion = DateTime.Now;
                                            theComponenteMQ.Request = documento.InnerXml;
                                            theComponenteMQ.TheComponenteTipo.Descripcion = "reversa Core Pago Credito Consumo";
                                            theComponenteMQ.TheComponenteCanal.IdCanal = 1;

                                            Binternacional.MessageQueue.Mensajeria.EnvioMensajeMessageQueue(theComponenteMQ);
                                        }

                                        if (TheTransaccion.Producto == "TransFerenciaTerceros")
                                        {
                                            //flujo Envio CCA comunicaicon Con componte Socket y manejo de Exceptions Gateway
                                            Binternacional.Socket.Conection.EnvioPorSocket(string.Empty, string.Empty, respuesta.InnerXml, 30000);


                                            //si contiene erorr Gateway Realizar reversa del cargo

                                            ComponenteMQ theComponenteMQ = new ComponenteMQ();
                                            theComponenteMQ.FechaTransaccion = DateTime.Now;
                                            theComponenteMQ.Request = documento.InnerXml;
                                            theComponenteMQ.TheComponenteTipo.Descripcion = "reversa Core Trasnferencia a Terceros";
                                            theComponenteMQ.TheComponenteCanal.IdCanal = 1;

                                            Binternacional.MessageQueue.Mensajeria.EnvioMensajeMessageQueue(theComponenteMQ);
                                        }



                                    }


                                }
                                else
                                {
                                    theRespuestaTransaccion.Codigo = "03";
                                    theRespuestaTransaccion.FccRef = string.Empty;
                                    theRespuestaTransaccion.Respuesta = "Codigo Producto no existe";
                                }

                            }

                            else
                            {
                                theRespuestaTransaccion.Codigo = "02";
                                theRespuestaTransaccion.FccRef = string.Empty;
                                theRespuestaTransaccion.Respuesta = "Debe Ingresar todos los parametros necesarios para realizar la transaccion";

                            }
                        }
                        else
                        {


                            theRespuestaTransaccion.Codigo = "01";
                            theRespuestaTransaccion.FccRef = "";
                            theRespuestaTransaccion.Respuesta = "el token de seguridad no es valido";
                        }
                    }
                    else
                    {
                        theRespuestaTransaccion.Codigo = "03";
                        theRespuestaTransaccion.FccRef = "";
                        theRespuestaTransaccion.Respuesta = "debe ingresar token de seguridad para realizar transaccion";
                    }

                }
                else
                {
                    theRespuestaTransaccion.Codigo = "03";
                    theRespuestaTransaccion.FccRef = "";
                    theRespuestaTransaccion.Respuesta = "debe ingresar token de seguridad para realizar transaccion";
                }

            }
            catch (Exception ex)
            {
                var lineNumber = new System.Diagnostics.StackTrace(ex, true).GetFrame(0).GetFileLineNumber();

                Binternacional.DTO.Componente theComponente = new Componente();
                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 3;
                theComponente.Mensaje = "Linea codigo " + lineNumber + " " + ex.Message + ex.StackTrace;
                theComponente.Metodo = "ejecutarTransaccion";

                Binternacional.Transversal.Log.ins_error(theComponente);

            }


            return theRespuestaTransaccion;

            //Binternacional.MQ.MQ theMq = new MQ.MQ();
            //XmlDocument documento = LoadEstructuraTransaccion(TheTransaccion.Producto);
            //XmlDocument respuesta = new XmlDocument();

            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/SCODE").InnerXml = TheTransaccion.Scode;
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/XREF").InnerXml = Binternacional.Transversal.Util.GeneraCorrelativoFCC();
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/BRN").InnerXml = TheTransaccion.Sucursal;
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/PRD").InnerXml = TheTransaccion.Producto;
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNDATE").InnerXml = "20151014";
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNCCY").InnerXml = TheTransaccion.Moneda;
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNAMT").InnerXml = TheTransaccion.MontoTransaccion;
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNBRN").InnerXml = TheTransaccion.Sucursal;

            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/TXNACC").InnerXml = TheTransaccion.NumeroCuentaOrigen.ToString();
            //documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/AUTHSTAT").InnerXml = "A";//parametro
            /////Parametros de Destino


            //if (TheTransaccion.Producto == "ILAC" || TheTransaccion.Producto == "ICTE" || TheTransaccion.Producto == "IBCO" || TheTransaccion.Producto == "IBTG" || TheTransaccion.Producto == "IBSP" || TheTransaccion.Producto == "IBCO")
            //{
            //    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETCCY").InnerXml = TheTransaccion.Moneda;
            //    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETAMT").InnerXml = TheTransaccion.MontoTransaccion;
            //    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETACCBRN").InnerXml = TheTransaccion.Sucursal;
            //    documento.SelectSingleNode("FCCRT/UPLOAD_RTL_TELLERTXN/OFFSETACC").InnerXml = TheTransaccion.NumeroCuentaDestino.ToString();

            //}


            //Thread mobjDebitoCoreThread = null;
            //Exception wobjThreadException = null;

            //try
            //{

            //    respuesta.LoadXml(theMq.LlamarServicio(documento.InnerXml, TheTransaccion.TheComponenteCanal.IdCanal).Replace("!<!DOCTYPE FCCRT SYSTEM './FCCRT.DTD'>", string.Empty).ToString());



            //    theRespuestaTransaccion.FccRef = respuesta.SelectSingleNode("FCCRT/REPLY_RTL_TELLERTXN/FCCREF").InnerText;
            //    theRespuestaTransaccion.Codigo = "00";
            //    theRespuestaTransaccion.Respuesta = "Transaccion Realizada de forma exitosa";


            //    ///flujo Tarjeta Credito




            //    //mobjDebitoCoreThread = new Thread(delegate()
            //    //{
            //    //    try
            //    //    {

            //    //        theMq.LlamarServicio(documento.InnerXml, TheTransaccion.TheComponenteCanal.IdCanal);
            //    //    }

            //    //    catch (Exception eobjException)
            //    //    {
            //    //        wobjThreadException = eobjException;
            //    //    }
            //    //});
            //    //mobjDebitoCoreThread.Start();


            //    //if (!mobjDebitoCoreThread.Join(3000))
            //    //{
            //    //    mobjDebitoCoreThread.Abort();
            //    //    ///encolar servicio de Reversa
            //    //    // ReversaCore();

            //    //    ///genear error a cliente generico Grabar el error de timeOut en Sistame
            //    //    Binternacional.DTO.Componente theComponente = new Componente();
            //    //    theComponente.TheComponenteCanal.IdCanal = 1;
            //    //    theComponente.TheComponenteTipo.IdComponenteTipo = 3;

            //    //    ///// verificar si contiene Error
            //    //    //if (respuesta.Contains("FCCRT/ERROR_RTL_TELLERTXN/ERROR"))
            //    //    //    theComponente.Mensaje = "Time Out Core Se encola Reversa {0'}:" + respuesta;
            //    //    //else
            //    //    //    theComponente.Mensaje = "Time Out Core Se encola Reversa";


            //    //    Binternacional.Transversal.Log.ins_error(theComponente);
            //    //    Binternacional.DTO.ComponenteMQ theComponenteMQ = new ComponenteMQ();

            //    //    theComponenteMQ.Request = documento.InnerXml;
            //    //    Binternacional.MessageQueue.Mensajeria.EnvioMensajeMessageQueue(theComponenteMQ);




            //    //    Binternacional.DTO.Reversa theReversa = new DTO.Reversa();
            //    //    theReversa.CodigoTransaccion = "1";
            //    //    theReversa.TheComponenteCanal = new DTO.ComponenteCanal();
            //    //    theReversa.TheComponenteCanal.IdCanal = 1;
            //    //    theReversa.TheTipoTransaccion.Id = 1;
            //    //    theReversa.Mensaje = documento.InnerXml;
            //    //    theReversa.TheReversaEstado = new DTO.ReversaEstado();
            //    //    theReversa.TheReversaEstado.IdEstado = 1;

            //    //    Binternacional.Transversal.Log.ins_reversa(theReversa);



            //    //}
            //}
            //catch (Exception ex)
            //{
            //    Binternacional.DTO.Componente theComponente = new Componente();
            //    theComponente.TheComponenteCanal.IdCanal = 1;
            //    theComponente.TheComponenteTipo.IdComponenteTipo = 3;
            //    theComponente.Mensaje = ex.Message;
            //    theComponente.Metodo = "ejecutarTransaccion";

            //    Binternacional.Transversal.Log.ins_error(theComponente);
            //}
            //return theRespuestaTransaccion;

        }



    }
}
