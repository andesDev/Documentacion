﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Binternacional.Web
{
    public partial class Parametros : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {
                CargaParametroGrupo();
                CargaParametros();
            }

        }
        protected void CargaParametroGrupo()
        {
            //ddlTipoParametro.DataSource = Binternacional.Transversal.Util.getParametroGrupo().ToList();
            //ddlTipoParametro.DataTextField = "descripcion";
            //ddlTipoParametro.DataValueField = "IdGrupo";
            //ddlTipoParametro.DataBind();
        }
        protected void CargaParametros()
        {
            grdParametros.DataSource = Binternacional.Transversal.Util.getParametro();
            grdParametros.DataBind();
        }

        protected void btnGrabar_onclick(object sender, EventArgs e)
        {
            Binternacional.DTO.Parametro theParametro = new DTO.Parametro();
            theParametro.UsuarioIngreso = "jperez";
            theParametro.TheParametroGrupo.IdGrupo = int.Parse(ddlTipoParametro.SelectedValue);
            theParametro.Codigo = txtCodigo.Value;
            theParametro.Descripcion = txtDescripcion.Value;
            theParametro.Mensaje = txtMensaje.Value;

            if (ckReversa.Checked)
                theParametro.Reversa = 1;
            else
                theParametro.Reversa = 0;

            Binternacional.Transversal.Util.insertParametro(theParametro);
            ///desplegar ventan modal hacia usuario
            ///
            CargaParametros();

        }
    }
}