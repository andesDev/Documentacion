﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Binternacional.Web
{
    public partial class ParametroGrupo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CargarGrupo();
            }

        }

        protected void btnGrabar_onclick(object sender, EventArgs e)
        {
            Binternacional.DTO.ParametroGrupo theParametroGrupo=new DTO.ParametroGrupo();
            theParametroGrupo.Descripcion = txtDescripcion.Value;
            theParametroGrupo.UsuarioIngreso = "jperez";

            Binternacional.Transversal.Util.insertParametroGrupo(theParametroGrupo);
            ///desplegar ventan modal hacia usuario
            ///
            CargarGrupo();

        }
        protected void CargarGrupo()
        {
         //   grdParametrosGrupo.DataSource = Binternacional.Transversal.Util.getParametroGrupo();
          //  grdParametrosGrupo.DataBind();
        }        

    }
}