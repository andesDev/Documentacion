﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;

namespace Binternacional.Web
{
    public partial class Exceptions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                CargaErroresComponente1();
            
        }

        [WebMethod]
        public static List<Binternacional.DTO.Componente> CargaErroresComponente()
        {
            List<Binternacional.DTO.Componente> collComponente = new List<DTO.Componente>();
            collComponente = Binternacional.Transversal.Util.getComponenteError();
            return collComponente;

        }
        protected void CargaErroresComponente1()
        {
            grdExceptions.DataSource = Binternacional.Transversal.Util.getComponenteError();
            grdExceptions.DataBind();
        }
      
    }
}