﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using BI.Service.Configuracion;
using System.Linq;
using System.Threading;


namespace Binternacional.LabKTF
{


    class Program
    {


        static void Main(string[] args)
        {

            XmlDocument reversa = new XmlDocument();
            reversa.LoadXml(@"<?xml version='1.0' encoding='UTF-8'?><FCCRT><UPLOAD_RTL_REVERSE><SCODE></SCODE><XREF></XREF> <SMS><USER_ID/></SMS></UPLOAD_RTL_REVERSE></FCCRT>");



            string rut = "139285972";

            rut = rut.Substring(rut.Length - 1, rut.Length);
            //= "13928597";// theTransaccion.RutCliente.Substring(theTransaccion.RutCliente.Length - 1, theTransaccion.RutCliente.Length);
            //        wobjDetalle[contador].DV = "2";// theTransaccion.RutCliente.Substring(theTransaccion.RutCliente.Length - 1, 1);


            XmlDocument documento = new XmlDocument();

            //            documento.LoadXml(@"<?xml version=""1.0"" encoding=""UTF-8""?><!DOCTYPE FCCRT SYSTEM ""./FCCRT.DTD""[]><FCCRT><ERROR_RTL_TELLERTXN><XREF>IB16111516574873</XREF><ERROR><ECODE>IF-DAT013</ECODE><EDESC>Can not Upload Contract for External Reference Number,
            //    $1</EDESC></ERROR><ERROR><ECODE>IF-DAT013</ECODE><EDESC>No se puede cargar el contrato para el Número de referencia externa $1.</EDESC></ERROR></ERROR_RTL_TELLERTXN></FCCRT>");

            documento.LoadXml(@"<?xml version=""1.0"" encoding=""UTF-8""?> <!DOCTYPE FCCRT SYSTEM ""./FCCRT.DTD""> <FCCRT>  <REPLY_RTL_TELLERTXN>      <XREF>IB1611161127464</XREF>      <RTDETAILS>          <FCCREF>001ILAC161862522</FCCREF>          <BRN>001</BRN>          <PROD>ILAC</PROD>          <RELCUST>0060558485</RELCUST>          <TXNBRN>001</TXNBRN>          <TXNACC>67042183552</TXNACC>          <TXNCCY>CLP</TXNCCY>          <TXNAMT>1</TXNAMT>          <TXNDT>20151014</TXNDT>          <OFFSETCCY>CLP</OFFSETCCY>          <OFFSETACCBRN>001</OFFSETACCBRN>          <OFFSETACC>67042327302</OFFSETACC>          <EXRT>1</EXRT>          <VALDT>20151014</VALDT>          <LCYAMT>1</LCYAMT>          <RUTNO>0060558485</RUTNO>          <QRYDT>20161116</QRYDT>          <AUTHSTAT>A</AUTHSTAT>      </RTDETAILS>  </REPLY_RTL_TELLERTXN></FCCRT>");


            // documento.LoadXml(documento.InnerXml.Replace("<!DOCTYPE FCCRT SYSTEM \"./FCCRT.DTD\"[]>", string.Empty));

            string valor = documento.InnerXml;
            string resultado = valor.Substring(documento.InnerXml.IndexOf("<FCCRT>"));
            documento.LoadXml(resultado);

            string salida = documento.SelectSingleNode("FCCRT/REPLY_RTL_TELLERTXN/FCCREF").InnerText;
            //var timerTrx = Stopwatch.StartNew();
            //Action calculo = () => { for (int i = 0; i < 1000; i++);};
            //Action<Action> measure = (body) =>
            //{
            //    ArrayList arreglo = new ArrayList();
            //    string statesKey = "TraOtrosBco";

            //    XmlDocument xmlResponse = new XmlDocument();
            //    String[,] aparams = new String[14, 2];

            //    aparams[0, 0] = "TXNCCY"; aparams[0, 1] = "CLP";
            //    aparams[1, 0] = "TXNAMT"; aparams[1, 1] = "1";
            //    aparams[2, 0] = "XREF"; aparams[2, 1] = "IBNK" + BI.Service.Configuracion.Generador.GetCorrelativoUnico();
            //    aparams[3, 0] = "Debito/TXNACC"; aparams[3, 1] = "67042183552";
            //    aparams[4, 0] = "Debito/TXNTipoCuenta"; aparams[4, 1] = "20";
            //    aparams[5, 0] = "Debito/GiradorRUT"; aparams[5, 1] = "0060558485";
            //    aparams[6, 0] = "Debito/GiradorNom"; aparams[6, 1] = "Oscar Ballarin";
            //    aparams[7, 0] = "Debito/TXNBRN"; aparams[7, 1] = "001";
            //    aparams[8, 0] = "Credito/TXNBRN"; aparams[8, 1] = "001";
            //    aparams[9, 0] = "Credito/TXNACC"; aparams[9, 1] = "333434344434";
            //    aparams[10, 0] = "Credito/TXNTipoCuenta"; aparams[10, 1] = "20";
            //    aparams[11, 0] = "Credito/BancoDesCod"; aparams[11, 1] = "37";
            //    aparams[12, 0] = "Credito/DestinatarioRUT"; aparams[12, 1] = "171915872";
            //    aparams[13, 0] = "Credito/DestinatarioNom"; aparams[13, 1] = "Juan Luis Perez";




            //    if (!callTrxPublico(statesKey, aparams, ref xmlResponse))
            //    {
            //        throw new Exception(xmlResponse.SelectSingleNode("Error").InnerText);
            //    }
            //    else
            //    {
            //        if (xmlResponse.SelectSingleNode("Respuesta").HasChildNodes)
            //        {
            //            XmlNode xmlMod = xmlResponse.SelectSingleNode("Respuesta");

            //            arreglo.Add(xmlMod.SelectSingleNode("XREF").InnerText);
            //            arreglo.Add(xmlMod.SelectSingleNode("FCCREF").InnerText);
            //        }
            //    }
            //    int valor = 0;
            //    valor++;
            //    Console.WriteLine("Cargo realizado al core" + "" + arreglo[0].ToString(), arreglo[1].ToString());
            //};

            //timerTrx.Stop();
            //Console.WriteLine("Tiempo total de ejecucion 100 transacciones" + timerTrx.ToString());

            //Enumerable.Range(1, 100)
            // .AsParallel()
            // .ForAll(_ => measure(calculo));



            //////test de rendimiento KTF y Flexcueb
            //for (int i = 0; i < 100; i++)
            //{
            //    ArrayList arreglo = new ArrayList();
            //    string statesKey = "TraOtrosBco";

            //    XmlDocument xmlResponse = new XmlDocument();
            //    String[,] aparams = new String[14, 2];

            //    aparams[0, 0] = "TXNCCY"; aparams[0, 1] = "CLP";
            //    aparams[1, 0] = "TXNAMT"; aparams[1, 1] = "1";
            //    aparams[2, 0] = "XREF"; aparams[2, 1] = "IBNK" + BI.Service.Configuracion.Generador.GetCorrelativoUnico();
            //    aparams[3, 0] = "Debito/TXNACC"; aparams[3, 1] = "67042183552";
            //    aparams[4, 0] = "Debito/TXNTipoCuenta"; aparams[4, 1] = "20";
            //    aparams[5, 0] = "Debito/GiradorRUT"; aparams[5, 1] = "0060558485";
            //    aparams[6, 0] = "Debito/GiradorNom"; aparams[6, 1] = "Oscar Ballarin";
            //    aparams[7, 0] = "Debito/TXNBRN"; aparams[7, 1] = "001";
            //    aparams[8, 0] = "Credito/TXNBRN"; aparams[8, 1] = "001";
            //    aparams[9, 0] = "Credito/TXNACC"; aparams[9, 1] = "333434344434";
            //    aparams[10, 0] = "Credito/TXNTipoCuenta"; aparams[10, 1] = "20";
            //    aparams[11, 0] = "Credito/BancoDesCod"; aparams[11, 1] = "37";
            //    aparams[12, 0] = "Credito/DestinatarioRUT"; aparams[12, 1] = "171915872";
            //    aparams[13, 0] = "Credito/DestinatarioNom"; aparams[13, 1] = "Juan Luis Perez";




            //    if (!callTrxPublico(statesKey, aparams, ref xmlResponse))
            //    {
            //        throw new Exception(xmlResponse.SelectSingleNode("Error").InnerText);
            //    }
            //    else
            //    {
            //        if (xmlResponse.SelectSingleNode("Respuesta").HasChildNodes)
            //        {
            //            XmlNode xmlMod = xmlResponse.SelectSingleNode("Respuesta");

            //            arreglo.Add(xmlMod.SelectSingleNode("XREF").InnerText);
            //            arreglo.Add(xmlMod.SelectSingleNode("FCCREF").InnerText);
            //        }
            //    }
            //    Console.WriteLine("Cargo realizado al core" + "" + arreglo[0].ToString(), arreglo[1].ToString());
            //}

            Console.ReadLine();


        }



        //public static Boolean callTrxPublico(string trxName, string[,] trxParams, ref XmlDocument xmlResponse)
        //{
        //    XmlDocument xmlRequest = new XmlDocument(); ;
        //    string sXmlResponse = "";
        //    string sKTFError = "";
        //    try
        //    {
        //        xmlRequest.LoadXml(BI.Service.Configuracion.Xml.GetXmlRequest());
        //        xmlRequest.SelectSingleNode("KTFRequest/TransaccionCod").InnerText = trxName;

        //        xmlRequest.SelectSingleNode("KTFRequest/Contexto/GrupoCod").InnerText = "0";
        //        xmlRequest.SelectSingleNode("KTFRequest/Contexto/TerminalID").InnerText = "172.16.12.226";
        //        xmlRequest.SelectSingleNode("KTFRequest/Contexto/CanalCod").InnerText = BI.Service.Configuracion.Config.GetPropiedad("CanalCod");

        //        for (int i = 0; i < trxParams.GetLength(0); i++)
        //        {
        //            string xpath = "";
        //            foreach (string nodo in trxParams[i, 0].Split(new Char[] { '/' }))
        //            {
        //                if (xmlRequest.SelectNodes("KTFRequest/Parametros" + Formato.LimpiaParametro(xpath) + "/" + nodo).Count == 0)
        //                    xmlRequest.SelectSingleNode("KTFRequest/Parametros" + Formato.LimpiaParametro(xpath)).InnerXml += "<" + Formato.LimpiaParametro(nodo) + "/>";

        //                xpath += "/" + nodo;
        //            }
        //            xmlRequest.SelectSingleNode("KTFRequest/Parametros" + Formato.LimpiaParametro(xpath)).InnerXml = Formato.LimpiaParametro(trxParams[i, 1]);
        //        }

        //        var timerTrx = Stopwatch.StartNew();
        //        //JPEREZ
        //        int result = KTF.Adapter.Ejecutar(xmlRequest.OuterXml, ref sXmlResponse);

        //        timerTrx.Stop();
        //        xmlResponse.LoadXml(sXmlResponse);
        //        if (sXmlResponse.Trim() == "")
        //        {
        //            sXmlResponse = "<Error><ErrorCod>1</ErrorCod><ErrorDes>" + sKTFError + "</ErrorDes></Error>";
        //            return false;
        //        }

        //        switch (result)
        //        {
        //            case 0: //EJECUTO OK
        //                sXmlResponse = xmlResponse.SelectSingleNode("KTFResponse/Datos").InnerXml;
        //                sXmlResponse = "<Respuesta>" + sXmlResponse + "</Respuesta>";
        //                xmlResponse.LoadXml(sXmlResponse);
        //                return true;
        //            //case -1: //Excepcion en el adaptador.
        //            //case 1: //Excepcion Técnica KTF.
        //            //case 2: //Excepción Funcional KTF.
        //            default:
        //                sXmlResponse = "<Error><ErrorCod></ErrorCod><ErrorDes>" + xmlResponse.SelectSingleNode("KTFResponse/Errores/Error/ErrorDes").InnerXml + "</ErrorDes></Error>";
        //                xmlResponse.LoadXml(sXmlResponse);
        //                return false;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        sXmlResponse = "<Error><ErrorCod>-9999</ErrorCod><ErrorDes>" + ex.Message + "</ErrorDes></Error>";
        //        return false;
        //    }
        //    finally
        //    {
        //        xmlResponse.LoadXml(sXmlResponse);
        //    }
        //}

    }
}
