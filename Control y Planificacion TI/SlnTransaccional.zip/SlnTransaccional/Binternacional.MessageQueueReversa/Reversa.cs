﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Messaging;

namespace Binternacional.MessageQueueReversa
{

    public class Transacion
    {
        private string tipoTransaccion;

        public string TipoTransaccion
        {
            get { return tipoTransaccion; }
            set { tipoTransaccion = value; }
        }
        private string fechaTransacion;

        public string FechaTransacion
        {
            get { return fechaTransacion; }
            set { fechaTransacion = value; }
        }
        private string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }
    }

    public class Reversa
    {
        /// <summary>
        /// realiza lectura de mensajes encolados en MessageQueue Microsoft
        /// </summary>
        public static void LeerMessageQueue()
        {
            string response = string.Empty;
            ///consulta por existencia de cola MQ
            Console.WriteLine("comieza a leer mensaje");
            Transacion theTransaccion = new Transacion();
            System.Messaging.MessageQueue wobjMessageQueue = null;
            try
            {
                wobjMessageQueue = new System.Messaging.MessageQueue(@".\Private$\transrevqueque");
                ///Asignacion de formato valido para deserializar mensaje
                wobjMessageQueue.Formatter = new XmlMessageFormatter(new Type[] { typeof(Transacion) });

                Message[] msgs = wobjMessageQueue.GetAllMessages();
                foreach (Message msg in msgs)
                {

                    var message = (Transacion)msg.Body;

                    // Display the label of each message.
                    Console.WriteLine("mensaje leido " + message.Mensaje + " Fecha Transaccion " + message.FechaTransacion + "Tipo Transaccion " + message.TipoTransaccion);
                    ///realiza envio a Colas MQ
                    ///actualiza log de transaciones tbl_reversa
                }

            }
            catch (MessageQueueException ex)
            {
                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    ///grabar Log ColasMQ

                }
                else
                {
                    ///grabar Log ColasMQ
                }
            }
            catch (Exception ex)
            {
                ///grabar Log ColasMQ
                Console.WriteLine(ex.Message);
            }
            finally
            {
                ///libera recursos System.componentModel.component
                wobjMessageQueue.Dispose();
                ///libera recursos System.Messaging.MessageQueue
                wobjMessageQueue.Close();
            }
        }
    }
}
