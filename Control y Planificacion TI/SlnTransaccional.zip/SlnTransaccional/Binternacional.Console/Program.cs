﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Binternacional.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Binternacional.DTO.Transaccion theTransaccion = new DTO.Transaccion();

            theTransaccion.Scode = "NPC";
            theTransaccion.Sucursal = "001";
            theTransaccion.Producto = "TEFA";
            theTransaccion.MontoTransaccion = "1000";// "100";
            theTransaccion.NumeroCuentaOrigen = "67042183552";
            theTransaccion.Moneda = "CLP";
            theTransaccion.Sucursal = "001";
            theTransaccion.NumeroCuentaDestino = "67042327302";
            theTransaccion.TheComponenteCanal.IdCanal = 1;
        }
    }
}
