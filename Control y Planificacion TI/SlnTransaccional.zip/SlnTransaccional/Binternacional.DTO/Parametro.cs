﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class Parametro : Base
    {
        /// <summary>
        /// id interno de parametro
        /// </summary>
        private int idParametro;

        public int IdParametro
        {
            get { return idParametro; }
            set { idParametro = value; }
        }
        /// <summary>
        /// descripcion o mensaje asociado al parametro
        /// </summary>
        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        /// <summary>
        /// codigo asociado al parametro(CCA codigo 046 usuario no corresponde con cuenta)
        /// </summary>
        private string codigo;

        public string Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }
        /// <summary>
        /// mensaje en caso de ser un transaccion esta contiene el XML de entrada para configurar futuras transacciones
        /// </summary>
        private string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }
        /// <summary>
        /// clase asociada al tipo de parametro
        /// </summary>
        private ParametroGrupo theParametroGrupo = new ParametroGrupo();


        public ParametroGrupo TheParametroGrupo
        {
            get { return theParametroGrupo; }
            set { theParametroGrupo = value; }
        }

        /// <summary>
        /// indica si parametro tiene una reversa asociada(reinsistencia para el caso de mensajes de no OK)
        /// </summary>
        private int reversa;

        public int Reversa
        {
            get { return reversa; }
            set { reversa = value; }
        }

    }
}
