﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class ReversaEstado
    {
        private int _idEstado;

        public int IdEstado
        {
            get { return _idEstado; }
            set { _idEstado = value; }
        }
        private string _descripcion;

        public string Descripcion
        {
            get { return _descripcion; }
            set { _descripcion = value; }
        }

    }
}
