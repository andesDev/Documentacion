﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    /// <summary>
    /// contiene todas las entidades que interactuan en los registros de log y Traza
    /// </summary>
    public class Componente
    {
        /// <summary>
        /// id interno de exception
        /// </summary>
        private int _idComponente;

        public int IdComponente
        {
            get { return _idComponente; }
            set { _idComponente = value; }
        }
        /// <summary>
        /// fecha en que se genero la exception
        /// </summary>
        private DateTime _fechaException;

        public DateTime FechaException
        {
            get { return _fechaException; }
            set { _fechaException = value; }
        }
        /// <summary>
        /// contiene mensajeria detalle con el error generado
        /// </summary>
        private string _mensaje;

        public string Mensaje
        {
            get { return _mensaje; }
            set { _mensaje = value; }
        }
        public ComponenteCanal theComponenteCanal=new ComponenteCanal();

        public ComponenteCanal TheComponenteCanal
        {
            get { return theComponenteCanal; }
            set { theComponenteCanal = value; }
        }
        public ComponenteTipo theComponenteTipo=new ComponenteTipo();

        public ComponenteTipo TheComponenteTipo
        {
            get { return theComponenteTipo; }
            set { theComponenteTipo = value; }
        }
        /// <summary>
        /// encapsula funcionalidad del metodo que genero la exception
        /// </summary>
        private string metodo;

        public string Metodo
        {
            get { return metodo; }
            set { metodo = value; }
        }

        //public string DescripcionCanal { get { return TheComponenteCanal.Descripcion; } }

    }
}
