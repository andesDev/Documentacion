﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    /// <summary>
    /// contiene la estructura de respuesta de ejecucion de transacciones
    /// </summary>
    public class RespuestaTransaccion
    {
        /// <summary>
        /// Codigo generado por FCC como respuesta a una transaccion exitosa
        /// </summary>
        private string fccRef;

        public string FccRef
        {
            get { return fccRef; }
            set { fccRef = value; }
        }
        private string xref;

        public string Xref
        {
            get { return xref; }
            set { xref = value; }
        }


        private string codigo;

        public string Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }
        private string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }

        private string respuesta;

        public string Respuesta
        {
            get { return respuesta; }
            set { respuesta = value; }
        }

    }
}
