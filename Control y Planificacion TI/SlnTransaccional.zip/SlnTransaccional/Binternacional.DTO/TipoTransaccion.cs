﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class TipoTransaccion
    {
        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        /// <summary>
        /// contiene codigo producto asociado a la transaccion
        /// </summary>
        private string codigoProducto;

        public string CodigoProducto
        {
            get { return codigoProducto; }
            set { codigoProducto = value; }
        }
    }
}
