﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    /// <summary>
    /// contiene la estructura de la reversa realizada
    /// </summary>
    public class Reversa
    {
        private int _idReversa;

        public int IdReversa
        {
            get { return _idReversa; }
            set { _idReversa = value; }
        }
        private string _codigoTransaccion;

        public string CodigoTransaccion
        {
            get { return _codigoTransaccion; }
            set { _codigoTransaccion = value; }
        }
        private string _mensaje;

        public string Mensaje
        {
            get { return _mensaje; }
            set { _mensaje = value; }
        }

        private DateTime _fechaRecepcionMensaje;

        public DateTime FechaRecepcionMensaje
        {
            get { return _fechaRecepcionMensaje; }
            set { _fechaRecepcionMensaje = value; }
        }
        private DateTime _fechaEnvioMensaje;

        public DateTime FechaEnvioMensaje
        {
            get { return _fechaEnvioMensaje; }
            set { _fechaEnvioMensaje = value; }
        }
        private int _numeroIntentos;

        public int NumeroIntentos
        {
            get { return _numeroIntentos; }
            set { _numeroIntentos = value; }
        }
        private ComponenteCanal theComponenteCanal=new ComponenteCanal();

        public ComponenteCanal TheComponenteCanal
        {
            get { return theComponenteCanal; }
            set { theComponenteCanal = value; }
        }

        private ReversaEstado theReversaEstado=new ReversaEstado();
      
        public ReversaEstado TheReversaEstado
        {
            get { return theReversaEstado; }
            set { theReversaEstado = value; }
        }
        private TipoTransaccion theTipoTransaccion = new TipoTransaccion();

        public TipoTransaccion TheTipoTransaccion
        {
            get { return theTipoTransaccion; }
            set { theTipoTransaccion = value; }
        }
       


    }
}
