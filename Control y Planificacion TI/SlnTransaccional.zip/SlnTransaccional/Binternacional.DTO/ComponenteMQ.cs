﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class ComponenteMQ
    {
        /// <summary>
        /// mensaje interno componente
        /// </summary>
        private int _idMensaje;

        public int IdMensaje
        {
            get { return _idMensaje; }
            set { _idMensaje = value; }
        }
        /// <summary>
        /// mensaje de Envio hacia Flexcube
        /// </summary>
        private string _request;
        
        public string Request
        {
            get { return _request; }
            set { _request = value; }
        }
        /// <summary>
        /// mensaje erspuesta flexcube
        /// </summary>
        private string _response;

        public string Response
        {
            get { return _response; }
            set { _response = value; }
        }
        private DateTime _fechaTransaccion;

        public DateTime FechaTransaccion
        {
            get { return _fechaTransaccion; }
            set { _fechaTransaccion = value; }
        }
        /// <summary>
        /// log asociado en caso que el mensaje tenga un error por algun componente alterno al proceso
        /// </summary>
        private int _logException;

        public int LogException
        {
            get { return _logException; }
            set { _logException = value; }
        }


        private ComponenteCanal theComponenteCanal = new ComponenteCanal();

        public ComponenteCanal TheComponenteCanal
        {
            get { return theComponenteCanal; }
            set { theComponenteCanal = value; }
        }
        private ComponenteTipo theComponenteTipo=new ComponenteTipo();


        public ComponenteTipo TheComponenteTipo
        {
            get { return theComponenteTipo; }
            set { theComponenteTipo = value; }
        }
    }
}
