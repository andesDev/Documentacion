﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    /// <summary>
    /// Contiene descripcion de tipos de componentes (MessageQueeu,MQ,Servicios,Gateway,CCA)
    /// </summary>
    public class ComponenteTipo
    {
        /// <summary>
        /// identificador interno de componente
        /// </summary>
        private int _idComponenteTipo;

        public int IdComponenteTipo
        {
            get { return _idComponenteTipo; }
            set { _idComponenteTipo = value; }
        }
        /// <summary>
        /// Descripcion de tipo componente
        /// </summary>
        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
    }
}
