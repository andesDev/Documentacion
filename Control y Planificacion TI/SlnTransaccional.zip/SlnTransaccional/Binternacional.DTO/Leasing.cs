﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class Leasing
    {
        private string numeroOperacion;

        public string NumeroOperacion
        {
            get { return numeroOperacion; }
            set { numeroOperacion = value; }
        }
        private string fechaVencimiento;

        public string FechaVencimiento
        {
            get { return fechaVencimiento; }
            set { fechaVencimiento = value; }
        }
        private string numeroReferencia;

        public string NumeroReferencia
        {
            get { return numeroReferencia; }
            set { numeroReferencia = value; }
        }
        private string numeroCuota;

        public string NumeroCuota
        {
            get { return numeroCuota; }
            set { numeroCuota = value; }
        }

        private string idOperacion;

        public string IdOperacion
        {
            get { return idOperacion; }
            set { idOperacion = value; }
        }
        private string valorCuota;

        public string ValorCuota
        {
            get { return valorCuota; }
            set { valorCuota = value; }
        }
        private string gastoCobranza;

        public string GastoCobranza
        {
            get { return gastoCobranza; }
            set { gastoCobranza = value; }
        }
        private string iva;

        public string Iva
        {
            get { return iva; }
            set { iva = value; }
        }
        private string mora;

        public string Mora
        {
            get { return mora; }
            set { mora = value; }
        }



    }
}
