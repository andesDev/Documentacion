﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class TarjetaCredito
    {
        private List<TarjetaCredito> collTarjetaCredito;

        public List<TarjetaCredito> CollTarjetaCredito
        {
            get { return collTarjetaCredito; }
            set { collTarjetaCredito = value; }
        }
        /// <summary>
        /// numero de tarjeta asociado a Tarjeta Credito
        /// </summary>
        private string numeroTarjeta;

        public string NumeroTarjeta
        {
            get { return numeroTarjeta; }
            set { numeroTarjeta = value; }
        }
        /// <summary>
        /// numero cuenta Asociado a tarjeta a tarjeta credito
        /// </summary>
        private string numeroCuenta;

        public string NumeroCuenta
        {
            get { return numeroCuenta; }
            set { numeroCuenta = value; }
        }
    
    }
}
