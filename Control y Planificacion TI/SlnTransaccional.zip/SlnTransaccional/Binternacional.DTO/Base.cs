﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    public class Base
    {
        
       

        private string usuarioIngreso;

        public string UsuarioIngreso
        {
            get { return usuarioIngreso; }
            set { usuarioIngreso = value; }
        }
        private string usuarioModificacion;

        public string UsuarioModificacion
        {
            get { return usuarioModificacion; }
            set { usuarioModificacion = value; }
        }
        private DateTime fechaIngreso;

        public DateTime FechaIngreso
        {
            get { return fechaIngreso; }
            set { fechaIngreso = value; }
        }
        private DateTime fechaModificacion;

        public DateTime FechaModificacion
        {
            get { return fechaModificacion; }
            set { fechaModificacion = value; }
        }
      

    }
}
