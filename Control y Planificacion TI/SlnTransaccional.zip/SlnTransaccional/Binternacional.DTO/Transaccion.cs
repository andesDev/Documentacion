﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{



    public class Transaccion
    {
        /// <summary>
        /// identificador de Tipo de Sistema
        /// </summary>
        private string scode;

        public string Scode
        {
            get { return scode; }
            set { scode = value; }
        }

        /// <summary>
        /// identificador de la transaccion
        /// </summary>
        private string identificadorTransaccion;

        public string IdentificadorTransaccion
        {
            get { return identificadorTransaccion; }
            set { identificadorTransaccion = value; }
        }

        private string sucursal;

        public string Sucursal
        {
            get { return sucursal; }
            set { sucursal = value; }
        }
        private string producto;

        public string Producto
        {
            get { return producto; }
            set { producto = value; }
        }
        private string moneda;

        public string Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }
        private string montoTransaccion;

        public string MontoTransaccion
        {
            get { return montoTransaccion; }
            set { montoTransaccion = value; }
        }
        private string numeroCuentaOrigen;

        public string NumeroCuentaOrigen
        {
            get { return numeroCuentaOrigen; }
            set { numeroCuentaOrigen = value; }
        }
        private string numeroCuentaDestino;

        public string NumeroCuentaDestino
        {
            get { return numeroCuentaDestino; }
            set { numeroCuentaDestino = value; }
        }

        private string rutCliente;

        public string RutCliente
        {
            get { return rutCliente; }
            set { rutCliente = value; }
        }
        private ComponenteCanal theComponenteCanal = new ComponenteCanal();

        public ComponenteCanal TheComponenteCanal
        {
            get { return theComponenteCanal; }
            set { theComponenteCanal = value; }
        }

        private TipoTransaccion theTipoTransaccion = new TipoTransaccion();

        public TipoTransaccion TheTipoTransaccion
        {
            get { return theTipoTransaccion; }
            set { theTipoTransaccion = value; }
        }
        private RespuestaTransaccion theRespuestaTransaccion = new RespuestaTransaccion();


        public RespuestaTransaccion TheRespuestaTransaccion
        {
            get { return theRespuestaTransaccion; }
            set { theRespuestaTransaccion = value; }
        }


        private TarjetaCredito theTarjetaCredito = new TarjetaCredito();


        public TarjetaCredito TheTarjetaCredito
        {
            get { return theTarjetaCredito; }
            set { theTarjetaCredito = value; }
        }

        private Leasing theLeasing = new Leasing();


        public Leasing TheLeasing
        {
            get { return theLeasing; }
            set { theLeasing = value; }

        }
    }
}
