﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Binternacional.DTO
{
    /// <summary>
    /// contiene detalle del canal que realizo llamada a compomente (mobile Banking,internet banking,Boton de pago ETC)
    /// </summary>
    public class ComponenteCanal:Base
    {
        private int _idCanal;

        public int IdCanal
        {
            get { return _idCanal; }
            set { _idCanal = value; }
        }

        private string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }

        private string token;

        public string Token
        {
            get { return token; }
            set { token = value; }
        }

    }
}
