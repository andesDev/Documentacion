﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Binternacional.Transversal;

namespace Binternacional.TestiadorComponente
{
    class Program
    {
        static void Main(string[] args)
        {
            string valor = Util.getlistaParametros("HoraDesdeLLamadaOnline", "Configuracion");

            Binternacional.MQ.MQ theMQ=new MQ.MQ();
            string fechaCore = theMQ.FechaCore.ToString();
        }
    }
}
