﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Caching;

namespace Binternacional.Caching
{
    public class Caching
    {

        /// <summary>
        /// remueve cache de Servidor al momento de realizar un cambio en la parametrizacion
        /// </summary>
        public static void RemoveCacheServer()
        {
            var cache = MemoryCache.Default;
            ///Contiene la informacion almacenada del servicio FechaHoraCore Flexcube
            cache.Remove("fechaCore");
            ///Contiene estructura completa de parametrizacion
            cache.Remove("Parametrizacion");
        }
    }
}
