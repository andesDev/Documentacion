﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Bintenacional.Transaccional.Services
{
   
    public class Service1 : IService1
    {
        /// <summary>
        /// servicio con estructura para realizar Cargo a Core y sus respectivos flujos a legados si corresponde
        /// </summary>
        /// <param name="theTransaccion"></param>
        /// <returns></returns>
        public Binternacional.DTO.RespuestaTransaccion EjecutarTransaccion(Binternacional.DTO.Transaccion theTransaccion)
        {
            Binternacional.DTO.RespuestaTransaccion theRespuestaTransaccion = new Binternacional.DTO.RespuestaTransaccion();
            Binternacional.Invoke.InvokeTransaccion theInvokeTransaccion = new Binternacional.Invoke.InvokeTransaccion();
            theRespuestaTransaccion = theInvokeTransaccion.ejecutarTransaccion(theTransaccion);

            return theRespuestaTransaccion;
        }
        /// <summary>
        /// remueve el chache del servidor al momento de realizar o modificar una nueva parametrizacio
        /// </summary>
        /// <param name="theTransaccion"></param>
        public void RemoveCacheParametrizacion(Binternacional.DTO.Transaccion theTransaccion)
        {
            Binternacional.Caching.Caching.RemoveCacheServer();
        }


    }
}
