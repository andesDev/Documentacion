﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using IBM.WMQ;

namespace Binternacional.Transaccion
{

    public class MQ
    {

        private MQQueue queue;

        private MQMessage queueMessage;

        private MQQueueManager queueManager;


        private string queueManagerName;
        private string host;
        private int port;
        private string channel;
        private string queueName;
        private Hashtable queueProperties;
        private string ConnName;

        private MQQueue InputQueue;
        private MQQueue OutputQueue;
        private UTF8Encoding utf8Enc;
        private int WaitInterval;
        private String msgText;

        public MQ()
        {

            setupTestData();

            queueManager = createQueueManager();

        }


        /// <summary>
        /// establece conexion a la Cola MQ Servidor 
        /// </summary>
        public void setupTestData()
        {
            queueManagerName = "MQBINTFOR";
            channel = "BINTFORMQSERVER";
            ConnName = "172.22.10.90(1446)";
            queueName = "IN_QUEUE";
            //host = "172.22.10.90";
            //port = 1446;
            //channel = "BINTFORMQSERVER";


            //queueProperties = new Hashtable();
            //queueProperties[MQC.HOST_NAME_PROPERTY] = host;
            //queueProperties[MQC.PORT_PROPERTY] = port;
            //queueProperties[MQC.CHANNEL_PROPERTY] = channel;

        }



        public MQQueueManager createQueueManager()
        {

            MQQueueManager queueManager = null;
            try
            {
                queueManager = new MQQueueManager(queueManagerName, channel, ConnName);
                Console.WriteLine("Connected Successfully");

            }

            catch (MQException mqexp)
            {

                Console.WriteLine("MQSeries Exception: " + mqexp.Message);
                Console.WriteLine("MQSeries Exception: " + mqexp.Reason);
                Console.WriteLine("MQSeries Exception: " + mqexp.StackTrace);

            }

            return queueManager;

        }


        /// <summary>
        /// envio de mensajeria a colas MQ
        /// </summary>
        /// <param name="message"></param>
        public string PutMessageOnQueue(string message)
        {
            string mensaje = string.Empty;
            try
            {
                queue = queueManager.AccessQueue(queueName, MQC.MQOO_OUTPUT);

                byte[] identificadorMensajeEnCola = AdjuntarMensaje(message);
                string str1 = this.ConseguirMensaje("OUT_QUEUE", identificadorMensajeEnCola).Trim();
                if (!string.IsNullOrEmpty(str1))
                    mensaje = str1;
                Console.WriteLine(str1);

                string str2 = this.ConseguirMensaje("IN_QUEUEE", identificadorMensajeEnCola).Trim();
                if (string.IsNullOrEmpty(str2))
                {
                    Console.WriteLine("ERROR: Servicio no responde");
                }
                else
                {
                    Console.WriteLine(str2);
                    mensaje = str2;
                }
            }

            catch (MQException mqexp)
            {

                Console.WriteLine("MQSeries Exception: " + mqexp.Message);

                Console.WriteLine("MQSeries Exception: " + mqexp.Reason);

                Console.WriteLine("MQSeries Exception: " + mqexp.StackTrace);

            }
            return mensaje;



        }
        public byte[] AdjuntarMensaje(string mensaje)
        {

            try
            {
                MQMessage message = new MQMessage();
                message.Format = "MQSTR";
                message.UserId = string.Empty;
                message.Persistence = 1;
                message.CorrelationId = Encoding.UTF8.GetBytes(Guid.NewGuid().ToString().Substring(0, 24));
                message.DataOffset = 0;
                message.WriteBytes(mensaje);
                message.MessageType = 8;
                message.Report = 0;
                message.ReplyToQueueName = "OUT_QUEUE";
                message.ReplyToQueueManagerName = string.Empty;
                ((MQDestination)queue).Put(message);

                return message.CorrelationId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (queue != null && queue.IsOpen)
                    queue.Close();
            }
        }
        private string ConseguirMensaje(string cola, byte[] identificadorMensajeEnCola)
        {

            MQMessage message = new MQMessage();
            MQQueue mqQueue = queueManager.AccessQueue(cola, 8193);
            MQGetMessageOptions gmo = new MQGetMessageOptions();
            message.Format = "MQSTR   ";
            message.UserId = string.Empty;
            message.CorrelationId = identificadorMensajeEnCola;
            gmo.MatchOptions = 3;
            gmo.Options = 16453;
            gmo.WaitInterval = Convert.ToInt32(360000);
            try
            {
                ((MQDestination)queue).Get(message, gmo);
                {
                  message.ReadString(message.MessageLength);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                if (queue != null && queue.IsOpen)
                    queue.Close();

            }
            return message.ReadString(message.MessageLength);
            
        }


        public string SendRequestToMQ(string RequestStream)
        {
            MQMessage MqsMsg = null;
            try
            {
                MQQueueManager queueManager = new MQQueueManager(queueManagerName, channel, ConnName);
                MqsMsg = new MQMessage();
                if (queueManager.IsConnected)
                    Console.WriteLine("Administrador MQ conectado");
                int InOpenOptions = MQC.MQOO_OUTPUT |
                                    MQC.MQOO_FAIL_IF_QUIESCING;
                int OutOpenOptions = MQC.MQOO_INPUT_AS_Q_DEF |
                                     MQC.MQOO_FAIL_IF_QUIESCING;
                InputQueue = queueManager.AccessQueue("IN_QUEUE", InOpenOptions);
                OutputQueue = queueManager.AccessQueue("OUT_QUEUE", OutOpenOptions);

                // Since .NET strings stores characters encoded
                // in a UTF-16 format, while a major portion
                // of the applications using IBM MQSeries are legacy
                // application, you might need to encode strings
                // in a UTF-8, or ASCII format in order for
                // the applications on the other side to be able
                // to understand your messages
                utf8Enc = new UTF8Encoding();
                MqsMsg.WriteBytes(Encoding.UTF8.GetBytes(RequestStream).ToString());
                MQPutMessageOptions pmo = new MQPutMessageOptions();
                InputQueue.Put(MqsMsg, pmo);
                Console.WriteLine("Ejecucion de Consulta" + MqsMsg.CorrelationId.ToString());
            }
            catch (MQException ex)
            {
                Console.WriteLine(ex.Message
                    + " " + ex.StackTrace);
                // Add your MQSeries exception handling here
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message
                   + " " + e.StackTrace);
                // Add your exception handling here
                // to handle exceptions of types other than MQException
            }


            MQMessage retrievedMessage = null;
            try
            {
                retrievedMessage = new MQMessage();
                retrievedMessage.CorrelationId = MqsMsg.CorrelationId;
                //Setting the get message options.. 
                MQGetMessageOptions gmo = new MQGetMessageOptions();
                // In order to activate "Wait on an empty queue";
                // you have to mask MQGetMessageOptions with MQGMO_WAIT 
                // for more details on other available options kindly refer to Appendix A
                gmo.Options = MQC.MQGMO_FAIL_IF_QUIESCING | MQC.MQGMO_WAIT;
                gmo.WaitInterval = WaitInterval;// wait time
                // to match using CorrelationID
                // or MQMO_MATCH_MSG_ID to match using MessageID
                gmo.MatchOptions = MQC.MQMO_MATCH_CORREL_ID;
                OutputQueue.Get(retrievedMessage, gmo);
                //writing Message result 
                msgText = retrievedMessage.ReadString(retrievedMessage.MessageLength);
            }
            catch (MQException ex)
            {
                Console.WriteLine(ex.Message
                   + " " + ex.StackTrace);
                // Add your MQSeries exception handling here 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message
                   + " " + e.StackTrace);
                // Add your exception handling here to
                // handle exceptions of types other than MQException
            }
            try
            {
                //Close the queue 
                OutputQueue.Close();
                InputQueue.Close();
                //Disconnect from the queue manager 
                queueManager.Disconnect();
            }
            catch (MQException ex)
            {
                Console.WriteLine(ex.Message
                   + " " + ex.StackTrace);
                // Add your MQSeries exception handling here 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message
                   + " " + e.StackTrace);
                // Add your exception handling here
                // to handle exceptions of types other than MQException
            }
            return msgText;
        }

    }

}

