﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IBM.WMQ;
using System.Configuration;
using System.Data;
using System.Xml;
using System.Runtime.Caching;

namespace Binternacional.Transaccion
{
    public class BinternacionalMQ
    {



        private TimeSpan objTiempoEspera = new TimeSpan(0, 0, 30);
        private string strNombreAdministradorColas;
        private string strCanal;
        private string strNombreConexion;
        private bool blnEjecutadoCorrectamente;


        /// <summary>
        /// parametrizacion En Cache Evitar muliples llamadas a la BD por ejecucion de transacciones
        /// </summary>
        private int fechaCore = 0;
        private int horaCiclo1Hasta = 0;
        private int horaCiclo1Desde = 0;
        private int horaCiclo2Desde = 0;
        private int horaCiclo2Hasta = 0;

        public string NombreAdministradorColas
        {
            get
            {
                if (string.IsNullOrEmpty(this.strNombreAdministradorColas))
                    this.strNombreAdministradorColas = ConfigurationManager.AppSettings["NombreAdministradorColas"];///leer desde dashboard
                return this.strNombreAdministradorColas;
            }
            set
            {
                this.strNombreAdministradorColas = value;
            }
        }



        public int _fechaCore
        {
            get
            {

                var cache = MemoryCache.Default;
                if (cache.Get("fechaCore") == null)
                {
                    ///obtengo Servicio
                    this.fechaCore = ObtieneFechaCore();

                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddYears(1);
                    policy.SlidingExpiration = TimeSpan.FromSeconds(3000);
                    ///se agrega valor de servicio en cache
                    cache.Set("fechaCore", fechaCore, policy.AbsoluteExpiration);

                }

                return this.fechaCore;
            }
            set
            {
                this.fechaCore = value;
            }
        }
        public int HoraCiclo1Desde
        {
            get
            {
                var cache = MemoryCache.Default;
                if (cache.Get("HORADESDECICLO1") == null)
                {
                    DataTable parametros = new DataTable();
                    ///obtengo parametro BD
                    this.horaCiclo1Desde = int.Parse(Parametrizacion.GetConsultaDescripcion("TEF", "HORADESDECICLO1", parametros));

                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddYears(1);///lectura posterior desde dashboard

                    ///se agrega valor de servicio en cache
                    cache.Set("HORADESDECICLO1", horaCiclo1Desde, policy.AbsoluteExpiration);

                }
                return this.horaCiclo1Desde;

            }
            set
            {
                this.horaCiclo1Desde = value;
            }
        }
        public int HoraCiclo1Hasta
        {

            get
            {
                var cache = MemoryCache.Default;
                if (cache.Get("HORAHASTACICLO1") == null)
                {
                    DataTable parametros = new DataTable();
                    ///obtengo parametro BD

                    this.horaCiclo1Hasta = int.Parse(Parametrizacion.GetConsultaDescripcion("TEF", "HORAHASTACICLO1", parametros));


                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddYears(1);///lectura posterior desde dashboard

                    ///se agrega valor de servicio en cache
                    cache.Set("HORAHASTACICLO1", horaCiclo1Hasta, policy.AbsoluteExpiration);

                }
                return this.horaCiclo1Hasta;

            }
            set
            {
                this.horaCiclo1Hasta = value;
            }
        }
        public int HoraCiclo2Desde
        {
            get
            {
                var cache = MemoryCache.Default;
                if (cache.Get("HORADESDECICLO2") == null)
                {
                    DataTable parametros = new DataTable();
                    ///obtengo parametro BD
                    this.horaCiclo2Desde = int.Parse(Parametrizacion.GetConsultaDescripcion("TEF", "HORADESDECICLO2", parametros));

                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddYears(1);///lectura posterior desde dashboard

                    ///se agrega valor de servicio en cache
                    cache.Set("HORADESDECICLO2", horaCiclo2Desde, policy.AbsoluteExpiration);

                }
                return this.horaCiclo2Desde;

            }
            set
            {
                this.horaCiclo2Desde = value;
            }
        }
        public int HoraCiclo2Hasta
        {
            get
            {
                var cache = MemoryCache.Default;
                if (cache.Get("HORAHASTACICLO2") == null)
                {
                    DataTable parametros = new DataTable();
                    ///obtengo parametro BD

                    this.horaCiclo2Hasta = int.Parse(Parametrizacion.GetConsultaDescripcion("TEF", "HORAHASTACICLO2", parametros));

                    //se declara politica de cache
                    var policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddYears(1);///lectura posterior desde dashboard

                    ///se agrega valor de servicio en cache
                    cache.Set("HORAHASTACICLO2", horaCiclo2Hasta, policy.AbsoluteExpiration);

                }
                return this.horaCiclo2Hasta;

            }
            set
            {
                this.horaCiclo2Hasta = value;
            }
        }

        public string Canal
        {
            get
            {
                if (string.IsNullOrEmpty(this.strCanal))
                    this.strCanal = ConfigurationManager.AppSettings["Canal"];
                return this.strCanal;
            }
            set
            {
                this.strCanal = value;
            }
        }


        public string NombreConexion
        {
            get
            {
                if (string.IsNullOrEmpty(this.strNombreConexion))
                    this.strNombreConexion = ConfigurationManager.AppSettings["NombreConexion"];
                return this.strNombreConexion;
            }
            set
            {
                this.strNombreConexion = value;
            }
        }

        public TimeSpan TiempoEspera
        {
            get
            {
                return this.objTiempoEspera;
            }
            set
            {
                this.objTiempoEspera = value;
            }
        }

        public bool EjecutadoCorrectamente
        {
            get
            {
                return this.blnEjecutadoCorrectamente;
            }
            private set
            {
                this.blnEjecutadoCorrectamente = value;
            }
        }

        /// <summary>
        /// genera correlativo unico de transaccion en flecube
        /// </summary>
        /// <returns></returns>
        public string GeneraCorrelativoFCC()
        {
            string millisecond = string.Empty;
            if (DateTime.Now.Millisecond.ToString().Count() == 3)
                millisecond = DateTime.Now.Millisecond.ToString().Substring(0, 2);

            return "IB" + DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month + DateTime.Now.Day + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + millisecond;

        }

        /// <summary>
        /// llamada de servicio
        /// </summary>
        /// <param name="strMessage"></param>
        /// <returns></returns>
        public string LlamarServicio(string strMessage)
        {
            string mensaje = string.Empty;

            try
            {

                this.EjecutadoCorrectamente = true;
                byte[] identificadorMensajeEnCola = this.AdjuntarMensaje(strMessage);
                string str1 = this.ConseguirMensaje("OUT_QUEUE", identificadorMensajeEnCola).Trim();
                if (!string.IsNullOrEmpty(str1))
                {
                    Console.WriteLine(str1 + "hola");
                    mensaje = str1;
                }

                this.EjecutadoCorrectamente = false;
                string str2 = this.ConseguirMensaje("IN_QUEUEE", identificadorMensajeEnCola).Trim();
                if (string.IsNullOrEmpty(str2))
                    return "ERROR: Servicio no responde";
                else

                    mensaje = str2;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
            }
            return mensaje;
        }
        /// <summary>
        /// ejecucion de mensaje en Colas MQ
        /// </summary>
        /// <param name="mensaje"></param>
        /// <returns></returns>
        /// 



        public void WriteMsg(string strInputMsg)
        {
            MQPutMessageOptions queuePutMessageOptions = null;
            MQQueue mqQueue = null;
            try
            {

                Console.WriteLine("escribiendo mensaje");
                mqQueue = new MQQueueManager(this.NombreAdministradorColas, this.Canal, this.NombreConexion).AccessQueue("IN_QUEUE", MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING);

                MQMessage message = new MQMessage();

                message.WriteString(strInputMsg);
                Console.WriteLine("se escribe mensaje");
                message.Format = MQC.MQFMT_STRING;


                mqQueue.Put(message, queuePutMessageOptions);

                Console.WriteLine("mensaje enviado exitosamente");
               // ReadMsg(message);


            }
            catch (MQException MQexp)
            {


                Console.WriteLine(MQexp.CompCode + "" + MQexp.Message);
                Console.WriteLine(MQexp.CompletionCode + MQexp.StackTrace);

                ///grabar Log 
                ///controlar Codigo de respuesta MQ de forma Clara
                //MQexp.CompletionCode
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message + "" + exp.StackTrace);

                ///grabar Log 
                ///controlar Codigo de respuesta MQ de forma Clara
                //MQexp.CompletionCode
            }
            finally
            {
                mqQueue.Close();
            }
        }
        public string ReadMsg(MQMessage mensaje)
        {
            string strReturn = string.Empty;
            Console.WriteLine("entro a leer Mensaje MQ");
            try
            {
                MQQueue OutputQueue = new MQQueueManager(this.NombreAdministradorColas, this.Canal, this.NombreConexion).AccessQueue("OUT_QUEUE", MQC.MQOO_OUTPUT | MQC.MQOO_BROWSE);
                Console.WriteLine("acceso a colas de SALiDA MQ");
                MQMessage retrievedMessage = new MQMessage();

                retrievedMessage.CorrelationId = mensaje.CorrelationId;

                Console.WriteLine("se asigno correlationID");
                MQGetMessageOptions queueGetMessageOptions = new MQGetMessageOptions();

                queueGetMessageOptions.Options = MQC.MQGMO_WAIT | MQC.MQGMO_BROWSE_FIRST;
                queueGetMessageOptions.WaitInterval = 5;

                queueGetMessageOptions.MatchOptions = MQC.MQMO_MATCH_CORREL_ID;

                int openInputOptions = MQC.MQOO_OUTPUT | MQC.MQOO_BROWSE;

                OutputQueue.Get(retrievedMessage, queueGetMessageOptions);

                strReturn = retrievedMessage.ReadString(retrievedMessage.MessageLength);

                Console.WriteLine("lectura exitosa " + strReturn);
            }
            catch (MQException MQexp)
            {
                Console.WriteLine(MQexp.CompCode + "" + MQexp.Message);
                Console.WriteLine(MQexp.CompletionCode + MQexp.StackTrace);
                ///grabar Log 
                ///controlar Codigo de respuesta MQ de forma Clara
                //MQexp.CompletionCode
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message + "" + exp.StackTrace);
                ///grabar Log 
                ///controlar Codigo de respuesta MQ de forma Clara
                //MQexp.CompletionCode
            }
            return strReturn;
        }


        private byte[] AdjuntarMensaje(string mensaje)
        {
            ValidaCicloFechaCore();

            MQQueue mqQueue = new MQQueueManager(this.NombreAdministradorColas, this.Canal, this.NombreConexion).AccessQueue("IN_QUEUE", 8208);
            try
            {
                MQMessage message = new MQMessage();
                message.Format = "MQSTR   ";
                message.UserId = string.Empty;
                message.Persistence = 1;
                message.CorrelationId = Encoding.UTF8.GetBytes(Guid.NewGuid().ToString().Substring(0, 24));
                message.DataOffset = 0;
                message.WriteBytes(mensaje);
                message.MessageType = 8;
                message.Report = 0;
                message.ReplyToQueueName = "OUT_QUEUE";
                message.ReplyToQueueManagerName = string.Empty;
                ((MQDestination)mqQueue).Put(message);
                Console.WriteLine("Mensaje Adjunto de forma exitosa");
                return message.CorrelationId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (mqQueue != null && mqQueue.IsOpen)
                    mqQueue.Close();
            }
        }

        /// <summary>
        /// obtencion fecha Core 
        /// </summary>
        private void ValidaCicloFechaCore()
        {

            if (fechaCore >= this.HoraCiclo1Desde && fechaCore <= this.HoraCiclo1Hasta)
                System.Threading.Thread.Sleep(30000);///configuracion desde Dashboard
            else if (fechaCore >= this.HoraCiclo2Desde && fechaCore <= this.HoraCiclo2Hasta)
                System.Threading.Thread.Sleep(30000);///configuracion desde Dashboard
        }
        private int ObtieneFechaCore()
        {
            WsObtieneFechaCore.Service1SoapClient service = new WsObtieneFechaCore.Service1SoapClient();
            XmlDocument response = new XmlDocument();
            int fechaCore = 0;

            try
            {

                service.Open();

                response.LoadXml(service.ObtieneFechaFCC());

                if (response.SelectSingleNode("KTF_Response").HasChildNodes)
                {
                    XmlNode xmlUsuario = response.SelectSingleNode("KTF_Response/FechasFCC");
                    fechaCore = int.Parse(xmlUsuario.SelectSingleNode("DIA_CONTABLE").InnerText);

                }

            }
            catch (Exception ex)
            {
                
                ///Grabar Log de Servicio
            }
            finally
            {
                service.Close();
            }
            return fechaCore;
        }

        private bool PagoTarjeta()
        {
            int contador = 0;
            bool response = false;
            WsPagoTarjeta.PagoTarjetasSoapClient service = new WsPagoTarjeta.PagoTarjetasSoapClient();
            WsPagoTarjeta.RETORNO wobjM_Cliente_XML = new WsPagoTarjeta.RETORNO();

            try
            {

                service.Open();
                WsPagoTarjeta.SAT_PAGO_ONLINE wobj = new WsPagoTarjeta.SAT_PAGO_ONLINE();
                wobj.FOLIO = GeneraCorrelativoFCC();

                WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE[] wobjDetalle = new WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE[9];
                wobjDetalle[contador] = new WsPagoTarjeta.SAT_PAGOS_ONLINE_DETALLE();


                wobjDetalle[contador].TDROL_ID = "";//xmlMod.SelectSingleNode("TDROL_ID").InnerText;
                wobjDetalle[contador].MONTO = "";//xmlMod.SelectSingleNode("MONTO").InnerText;
                wobjDetalle[contador].NUM_CUENTA = "";//xmlMod.SelectSingleNode("NUM_CUENTA").InnerText;
                wobjDetalle[contador].NUM_TARJETA = "";//xmlMod.SelectSingleNode("NUM_TARJETA").InnerText;
                wobjDetalle[contador].RUT = "";//xmlMod.SelectSingleNode("RUT").InnerText;
                wobjDetalle[contador].DV = "";//xmlMod.SelectSingleNode("DV").InnerText;




                wobj.PAGOS_ONLINE_DETALLE = wobjDetalle;

                wobjM_Cliente_XML = service.PAGO_ONLINE(wobj);
                if (!wobjM_Cliente_XML.ESTADO)
                {

                    Parametrizacion.InsLogPagoTarjeta(wobj.FOLIO, wobjDetalle[contador].TDROL_ID, wobjDetalle[contador].NUM_CUENTA,
                                            wobjDetalle[contador].NUM_TARJETA, wobjDetalle[contador].RUT,
                                            wobjDetalle[contador].DV, wobjDetalle[contador].MONTO, "E", wobjM_Cliente_XML.DESCRIPCION);
                    response = false;
                }


                else
                {
                    Parametrizacion.InsLogPagoTarjeta(wobj.FOLIO, wobjDetalle[contador].TDROL_ID, wobjDetalle[contador].NUM_CUENTA,
                                            wobjDetalle[contador].NUM_TARJETA, wobjDetalle[contador].RUT,
                                            wobjDetalle[contador].DV, wobjDetalle[contador].MONTO, "T", wobjM_Cliente_XML.DESCRIPCION);
                    response = true;
                }

            }
            catch (Exception ex)
            {
                ///grabar Log 
            }
            finally
            {

                service.Close();
            }
            return response;
        }






        //private void GetPagoREVTC(XmlDocument pdomRequest, XmlDocument pdomRespuesta)
        //{
        //    //Para el manejo de los errores
        //    //====================================================================================
        //    int wvarPaso = 0;
        //    //====================================================================================

        //    XmlSerializer wobjXmlSerializer = new XmlSerializer(typeof(dbinterpt1.RETORNO));
        //    StringBuilder wobjStringBuilder = new StringBuilder();

        //    dbinterpt1.PagoTarjetas wobjWebservice1 = new dbinterpt1.PagoTarjetas();
        //    dbinterpt1.RETORNO wobjM_Cliente_XML = new dbinterpt1.RETORNO();

        //    try
        //    {
        //        //Asigno la URL del Web Service.
        //        //====================================================================================
        //        wvarPaso = 10;
        //        wobjWebservice1.Url = FunConfig.GetPropiedad("SATWebServicePagoTC1");
        //        //====================================================================================

        //        dbinterpt1.SAT_PAGO_ONLINE wobj = new dbinterpt1.SAT_PAGO_ONLINE();

        //        wobj.FOLIO = mvarFolio;

        //        dbinterpt1.SAT_PAGOS_ONLINE_DETALLE[] wobjDetalle = new dbinterpt1.SAT_PAGOS_ONLINE_DETALLE[9];

        //        int contador = 0;
        //        string rol_id = string.Empty;

        //        foreach (XmlNode xmlMod in FunXml.GetParNodos(pdomRequest, "Detalles/Detalle"))
        //        {
        //            wobjDetalle[contador] = new dbinterpt1.SAT_PAGOS_ONLINE_DETALLE();

        //            rol_id = GeneradorCorrelativo.Generador.GetCorrelativoUnico();

        //            wobjDetalle[contador].TDROL_ID = rol_id;
        //            wobjDetalle[contador].MONTO = xmlMod.SelectSingleNode("MONTO").InnerText;
        //            wobjDetalle[contador].NUM_CUENTA = xmlMod.SelectSingleNode("NUM_CUENTA").InnerText;
        //            wobjDetalle[contador].NUM_TARJETA = xmlMod.SelectSingleNode("NUM_TARJETA").InnerText;
        //            wobjDetalle[contador].RUT = xmlMod.SelectSingleNode("RUT").InnerText;
        //            wobjDetalle[contador].DV = xmlMod.SelectSingleNode("DV").InnerText;

        //            //InsLogPagoTarjeta(mvarFolio, rol_id, xmlMod.SelectSingleNode("NUM_CUENTA").InnerText,
        //            //                    xmlMod.SelectSingleNode("NUM_TARJETA").InnerText, xmlMod.SelectSingleNode("RUT").InnerText,
        //            //                    xmlMod.SelectSingleNode("DV").InnerText, xmlMod.SelectSingleNode("MONTO").InnerText, "E");

        //            contador += 1;
        //        }

        //        wobj.PAGOS_ONLINE_DETALLE = wobjDetalle;

        //        //Ejecuto operación del WebService.
        //        //====================================================================================
        //        wvarPaso = 100;
        //        wobjM_Cliente_XML = wobjWebservice1.PAGO_ONLINE(wobj);
        //        //====================================================================================

        //        //Reviso código de error del WS.
        //        //====================================================================================
        //        wvarPaso = 110;
        //        if (!wobjM_Cliente_XML.ESTADO)
        //        {
        //            //Serializo el objeto M_Cliente_XML.
        //            //====================================================================================
        //            wvarPaso = 130;
        //            wobjXmlSerializer.Serialize(XmlWriter.Create(wobjStringBuilder), wobjM_Cliente_XML);
        //            //====================================================================================

        //            //Cargo el xml en el parámetro de salida.
        //            //====================================================================================
        //            wvarPaso = 140;
        //            pdomRespuesta.LoadXml(wobjStringBuilder.ToString());

        //            wvarPaso = 150;
        //            ReversaCore();

        //            //wvarPaso = 160;
        //            //ReversaPago(pdomRequest);

        //            wvarPaso = 170;
        //            SetFuncionalException(ERR_SAT_WS, wobjM_Cliente_XML.DESCRIPCION);
        //        }
        //        else
        //        {
        //            //REFERENTE AL LOG PARA MANEJAR LAS INTERFACES
        //            //getCambiaEstado(mvarFolio, "T");

        //            if (getConsultaCodigoPago(pdomRequest, mvarFolio))
        //            {
        //                //====================================================================================

        //                //Serializo el objeto M_Cliente_XML.
        //                //====================================================================================
        //                wvarPaso = 130;
        //                wobjXmlSerializer.Serialize(XmlWriter.Create(wobjStringBuilder), wobjM_Cliente_XML);
        //                //====================================================================================

        //                //Cargo el xml en el parámetro de salida.
        //                //====================================================================================
        //                wvarPaso = 140;
        //                pdomRespuesta.LoadXml(wobjStringBuilder.ToString());
        //                //====================================================================================	
        //            }
        //            else
        //            {
        //                //Serializo el objeto M_Cliente_XML.
        //                //====================================================================================
        //                wvarPaso = 130;
        //                wobjXmlSerializer.Serialize(XmlWriter.Create(wobjStringBuilder), wobjM_Cliente_XML);
        //                //====================================================================================

        //                //Cargo el xml en el parámetro de salida.
        //                //====================================================================================
        //                wvarPaso = 140;
        //                pdomRespuesta.LoadXml(wobjStringBuilder.ToString());

        //                wvarPaso = 150;
        //                ReversaCore();

        //                //wvarPaso = 160;
        //                //ReversaPago(pdomRequest);
        //                SetFuncionalException(ERR_SAT_WS, wobjM_Cliente_XML.DESCRIPCION);
        //            }
        //        }
        //    }

        //    #region Catch
        //    catch (System.Net.Sockets.SocketException eobjSocketException)
        //    {
        //        ReversaCore();
        //        //ReversaPago(pdomRequest);
        //        throw eobjSocketException;
        //    }

        //    catch (System.Net.WebException eobjWebException)
        //    {
        //        ReversaCore();
        //        //ReversaPago(pdomRequest);
        //        throw eobjWebException;
        //    }


        //    #endregion
        //}

        //private void ReversaCore()
        //{
        //    //Para el manejo de los errores
        //    //====================================================================================
        //    int wvarPaso = 0;
        //    //====================================================================================
        //    MessageQueue wobjMessageQueue = new MessageQueue(mvarTransRevQueue);
        //    MessageQueueTransaction wobjMessageQueueTransaction = new MessageQueueTransaction();
        //    Message wobjMessage = new Message();

        //    XmlDocument wdomKTFRequest = new XmlDocument();
        //    XmlDocument wdomCoreOut = new XmlDocument();

        //    const string REQUEST = "<KTFRequest>" +
        //                                "<TransaccionCod>TraOtrosBcoRev</TransaccionCod>" +
        //                                "<Contexto>" +
        //                                    "<UsuarioCod/>" +
        //                                    "<Password/>" +
        //                                    "<GrupoCod/>" +
        //                                    "<TerminalID/>" +
        //                                    "<TerminalUbicacion/>" +
        //                                    "<CanalCod/>" +
        //                                "</Contexto>" +
        //                                "<Parametros>" +
        //                                    "<Source/>" +
        //                                    "<SCODE/>" +
        //                                    "<DirectaCore/>" +
        //                                    "<Ciclo/>" +
        //                                    "<DebitoRev>" +
        //                                        "<XREF/>" +
        //                                        "<FCCREF/>" +
        //                                        "<TXNACC/>" +
        //                                        "<TXNTipoCuenta/>" +
        //                                        "<GiradorRUT/>" +
        //                                        "<GiradorNom/>" +
        //                                    "</DebitoRev>" +
        //                                    "<CreditoRev>" +
        //                                      "<BRN/>" +
        //                                      "<TXNCCY/>" +
        //                                      "<TXNAMT/>" +
        //                                      "<TXNBRN/>" +
        //                                      "<TXNACC/>" +
        //                                      "<TXNTipoCuenta/>" +
        //                                      "<BancoDesCod/>" +
        //                                      "<DestinatarioRUT/>" +
        //                                      "<DestinatarioNom/>" +
        //                                    "</CreditoRev>" +
        //                                "</Parametros>" +
        //                           "</KTFRequest>";

        //    try
        //    {
        //        //Cargo el esqueleto.
        //        //====================================================================================
        //        wvarPaso = 10;
        //        wdomKTFRequest.LoadXml(REQUEST);
        //        //====================================================================================

        //        //Cargo valores.
        //        //====================================================================================
        //        wvarPaso = 30;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/Source").InnerText = mvarSource;
        //        wvarPaso = 40;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/SCODE").InnerText = mvarSCODE;
        //        wvarPaso = 50;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DirectaCore").InnerText = "N";
        //        wvarPaso = 54;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/Ciclo").InnerText = getDevuelveCiclo(int.Parse(mvarHoraCore));

        //        wvarPaso = 60;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/XREF").InnerText = mvarXREF;
        //        wvarPaso = 70;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/FCCREF").InnerText = mvarFCCREF;
        //        wvarPaso = 80;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/TXNACC").InnerText = mvarTXNACCDb;
        //        wvarPaso = 90;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/TXNTipoCuenta").InnerText = "20";
        //        wvarPaso = 110;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/GiradorRUT").InnerText = mvarGiradorRUT;
        //        wvarPaso = 120;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/DebitoRev/GiradorNom").InnerText = mvarGiradorNom;

        //        wvarPaso = 220;
        //        wdomKTFRequest.SelectSingleNode("KTFRequest/Parametros/CreditoRev/TXNAMT").InnerText = mvarTXNAMT;
        //        //====================================================================================

        //        Log("KtTrTraOtrosBcoRev ENTRADA REVERSA CORE DESDE Tarjeta de Credito - " + wdomKTFRequest.InnerXml);

        //        wvarPaso = 300;
        //        wobjMessage.Label = "ReversaCore";
        //        wvarPaso = 310;
        //        wobjMessage.AppSpecific = mvarTransaccionNro;
        //        wvarPaso = 320;
        //        wobjMessage.Body = wdomKTFRequest.InnerXml;

        //        wvarPaso = 330;
        //        wobjMessageQueueTransaction.Begin();
        //        wvarPaso = 340;
        //        wobjMessageQueue.Send(wobjMessage,
        //                              wobjMessageQueueTransaction);
        //        wvarPaso = 360;
        //        wobjMessageQueueTransaction.Commit();

        //    }
        //    #region Catch
        //    catch (FuncionalException eobjFuncionalException)
        //    {
        //        throw eobjFuncionalException;
        //    }
        //    catch (FuncionalColException eobjFuncionalColException)
        //    {
        //        throw eobjFuncionalColException;
        //    }
        //    catch (TecnicaException eobjTecnicaException)
        //    {
        //        this.SetTecnicaException(eobjTecnicaException,
        //                                 wvarPaso);
        //    }
        //    catch (Exception eobjException)
        //    {
        //        this.SetException(eobjException,
        //                          wvarPaso);
        //    }
        //    #endregion
        //}

        private string ConseguirMensaje(string cola, byte[] identificadorMensajeEnCola)
        {
            Console.WriteLine("Conseguir Mensaje");
            MQQueueManager mqQueueManager = new MQQueueManager(this.NombreAdministradorColas, this.Canal, this.NombreConexion);
            MQQueue mqQueue = mqQueueManager.AccessQueue(cola, 8193);
            MQMessage message = new MQMessage();
            MQGetMessageOptions gmo = new MQGetMessageOptions();
            message.Format = "MQSTR";
            message.UserId = string.Empty;
            message.CorrelationId = identificadorMensajeEnCola;
            gmo.MatchOptions = 3;
            gmo.Options = 16453;
            gmo.WaitInterval = Convert.ToInt32(this.TiempoEspera.TotalMilliseconds);

            Console.WriteLine("PAso 2");
            try
            {
                ((MQDestination)mqQueue).Get(message, gmo);
                Console.WriteLine("PAso 3");

                string Response = message.ReadString(message.MessageLength);
                Console.WriteLine(Response.ToString().Replace("<!DOCTYPE FCCGENERIC SYSTEM \"./FCCGENERIC.DTD\">", string.Empty));
                return Response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
                return string.Empty;
            }
            finally
            {
                if (mqQueue != null && mqQueue.IsOpen)
                    mqQueue.Close();
                if (mqQueueManager != null && mqQueueManager.IsConnected)
                    mqQueueManager.Disconnect();
            }
        }
    }
}
