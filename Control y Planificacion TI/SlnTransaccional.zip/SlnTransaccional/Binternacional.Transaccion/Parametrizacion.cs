﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Binternacional.Transaccion
{
    /// <summary>
    /// Obtencion de parametrizacion Componente Transaccional
    /// Ciclos
    /// Moneda
    /// Tipo de Cuenta
    /// Sucursal
    /// </summary>
    public class Parametrizacion
    {
        /// <summary>
        /// Consulta Codigos para distintos tipos de parametrizacion
        /// </summary>
        /// <param name="pConcepto"></param>
        /// <param name="pCodigo"></param>
        /// <param name="pobjDataTable"></param>
        /// <returns></returns>
        public static string GetConsultaDescripcion(string pConcepto, string pCodigo, DataTable pobjDataTable)
        {

            string parametro = string.Empty;
            SQLHelper wobjSQLHelper = new SQLHelper();


            try
            {
                //Seteo Parámetros.
                //====================================================================================

                wobjSQLHelper.SetParametro("@Concepto",
                                           SqlDbType.VarChar,
                                           20,
                                           pConcepto);

                wobjSQLHelper.SetParametro("@Codigo",
                                          SqlDbType.VarChar,
                                          20,
                                          pCodigo);
                //====================================================================================


                //Ejecuto SP.
                //====================================================================================
                if (wobjSQLHelper.Ejecutar("wp_parametro_get_by_codigo_and_concepto",
                                           "KTF",
                                           pobjDataTable) > 0)
                {
                    foreach (DataRow dtRow in pobjDataTable.Rows)
                    {
                        parametro = dtRow["descripcion"].ToString();
                    }

                }


                //====================================================================================
            }

            #region Catch

            catch (Exception eobjException)
            {
                throw eobjException;
            }
            #endregion

            return parametro;
        }


 

        /// <summary>
        /// generar Log de Pago Tarjeta con respuesta de servicio SAT
        /// </summary>
        /// <param name="pFolioGrupo"></param>
        /// <param name="pFolioPago"></param>
        /// <param name="pNroCuenta"></param>
        /// <param name="pNroTarjeta"></param>
        /// <param name="pRut"></param>
        /// <param name="pDv"></param>
        /// <param name="pMonto"></param>
        /// <param name="pEstadoEnvio"></param>
        public static void InsLogPagoTarjeta(string pFolioGrupo, string pFolioPago, string pNroCuenta,
                                        string pNroTarjeta, string pRut, string pDv,
                                        string pMonto, string pEstadoEnvio,string pdescripcion)
        {
            SQLHelper wobjSQLHelper = new SQLHelper();

            try
            {

                wobjSQLHelper.SetParametro("@pFolioGrupo", SqlDbType.VarChar,30,pFolioGrupo);
                wobjSQLHelper.SetParametro("@pFolioPago",SqlDbType.VarChar,30,pFolioPago);
                wobjSQLHelper.SetParametro("@pNroCuenta", SqlDbType.VarChar,20,pNroCuenta);
                wobjSQLHelper.SetParametro("@pNroTarjeta",SqlDbType.VarChar,20,pNroTarjeta);
                wobjSQLHelper.SetParametro("@pRut",SqlDbType.VarChar,10,pRut);
                wobjSQLHelper.SetParametro("@pDV",SqlDbType.VarChar,1,pDv);
                wobjSQLHelper.SetParametro("@pMonto",SqlDbType.VarChar,20,pMonto);
                wobjSQLHelper.SetParametro("@pEstadoEnvio",SqlDbType.VarChar,1,pEstadoEnvio);
                wobjSQLHelper.SetParametro("@pDescripcion",SqlDbType.VarChar,5000,pdescripcion);

                switch (wobjSQLHelper.EjecutarNQ("INS_PagoTarjeta", "KTF"))
                {
                    case 0:
                           ///grabar Log BD Generar alerta en Dashboard
                        throw new Exception("No se pudo grabar el Log de Pago de Tarjeta de Credito");
                }
                //====================================================================================
            }

            catch (Exception ex)
            {   
                ///grabar Log BD Generar alerta en Dashboard
            
            }
        }

    }
}
