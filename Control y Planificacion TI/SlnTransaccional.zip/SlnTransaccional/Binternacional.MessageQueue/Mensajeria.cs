﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Messaging;
using System.Linq;
using System.Xml;

namespace Binternacional.MessageQueue
{


    public class Transacion
    {
        private string tipoTransaccion;

        public string TipoTransaccion
        {
            get { return tipoTransaccion; }
            set { tipoTransaccion = value; }
        }
        private string fechaTransacion;

        public string FechaTransacion
        {
            get { return fechaTransacion; }
            set { fechaTransacion = value; }
        }
        private string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }
    }


    public class Mensajeria
    {
        /// <summary>
        /// Elimina Cola Microsoft MessageQueue
        /// </summary>
        public static void EliminarMessageQueue()
        {
            System.Messaging.MessageQueue wobjMessageQueue = null;
            try
            {
                wobjMessageQueue = new System.Messaging.MessageQueue(".\\Private$\\TransRevQueue");
                Message wobjMessage = new Message();


                // if (System.Messaging.MessageQueue.Exists(".\\Private$\\transrevqueue"))
                if (System.Messaging.MessageQueue.Exists(wobjMessageQueue.QueueName))
                {
                    Console.WriteLine("Existe la cola buscada");
                    try
                    {
                        // Delete the queue.
                        System.Messaging.MessageQueue.Delete(".\\Private$\\transrevqueue");
                        Console.WriteLine("Elimina todos los mensajes de Colas MessageQueue");
                    }
                    catch (MessageQueueException e)
                    {
                        if (e.MessageQueueErrorCode ==
                            MessageQueueErrorCode.AccessDenied)
                        {
                            Console.WriteLine("Access is denied. " +
                                "Queue might be a system queue.");
                        }

                        // Handle other sources of MessageQueueException.
                    }

                }
                else
                {
                    Console.WriteLine("No Existe la cola buscada");
                }
            }
            catch (MessageQueueException ex)
            {
                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    ///grabar Log ColasMQ

                }
                else
                {
                    ///grabar Log ColasMQ
                }
            }
            catch (Exception ex)
            {

            }

            finally
            {
                ///libera recursos System.componentModel.component
                wobjMessageQueue.Dispose();
                ///libera recursos System.Messaging.MessageQueue
                wobjMessageQueue.Close();
            }

        }
        /// <summary>
        /// lectura de mensajes Colas MQ MessageQueue
        /// </summary>
        public static void LeerMessageQueue()
        {
            string response = string.Empty;
            ///consulta por existencia de cola MQ
            Console.WriteLine("comieza a leer mensaje");
            Transacion theTransaccion = new Transacion();
            System.Messaging.MessageQueue wobjMessageQueue = null;
            try
            {
                wobjMessageQueue = new System.Messaging.MessageQueue(@".\Private$\TransRevQueue");
                ///Asignacion de formato valido para deserializar mensaje
                wobjMessageQueue.Formatter = new XmlMessageFormatter(new Type[] { typeof(Transacion) });

                Message[] msgs = wobjMessageQueue.GetAllMessages();
                foreach (Message msg in msgs)
                {

                    var message = (Transacion)msg.Body;

                    // Display the label of each message.
                    Console.WriteLine("mensaje leido " + message.Mensaje + " Fecha Transaccion " + message.FechaTransacion + "Tipo Transaccion " + message.TipoTransaccion);

                }

            }
            catch (MessageQueueException ex)
            {
                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    ///grabar Log ColasMQ

                }
                else
                {
                    ///grabar Log ColasMQ
                }
            }
            catch (Exception ex)
            {
                ///grabar Log ColasMQ
                Console.WriteLine(ex.Message);
            }
            finally
            {
                ///libera recursos System.componentModel.component
                wobjMessageQueue.Dispose();
                ///libera recursos System.Messaging.MessageQueue
                wobjMessageQueue.Close();
            }
        }

        /// <summary>
        /// limpiar mensaje por Id transacion
        /// </summary>
        /// <param name="idMensaje"></param>
        public static void LimpiarMensajeMessageQueueByID(string idMensaje)
        {
            System.Messaging.MessageQueue queue = null;
            try
            {
                queue = new System.Messaging.MessageQueue(@".\Private$\TransRevQueue");

                ///retorna todos los mensajes activos encolados
                var messages = queue.GetAllMessages();

                Console.WriteLine("lista de todos los mensajes " + messages);

                ///elimina mensaje de cola MessageQueue mediante su ID unico
                var messagesToDelete = messages.Where(m => m.Id == idMensaje).ToList();

                messagesToDelete.ForEach(m => queue.ReceiveById(m.Id));

                Console.WriteLine("Mensaje Eliminado de forma exitosa");
            }
            catch (MessageQueueException ex)
            {
                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    ///grabar Log ColasMQ

                }
                else
                {
                    ///grabar Log ColasMQ
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
            }
            finally
            {
                queue.Dispose();
                queue.Close();

            }

        }

        /// <summary>
        /// limpiar totalidad de mensajes en Colas MQ
        /// </summary>
        public static void LimpiarTodosLosMensajesMessageQueue()
        {
            System.Messaging.MessageQueue wobjMessageQueue = null;
            try
            {
                wobjMessageQueue = new System.Messaging.MessageQueue(".\\Private$\\TransRevQueue");
                wobjMessageQueue.Purge();
            }
            catch (MessageQueueException ex)
            {
                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 2;
                    theComponente.Mensaje = ex.MessageQueueErrorCode + " " + ex.Message;

                    Binternacional.Transversal.Log.ins_error(theComponente);

                }
                else
                {
                    Binternacional.DTO.Componente theComponente = new DTO.Componente();

                    theComponente.TheComponenteCanal.IdCanal = 1;
                    theComponente.TheComponenteTipo.IdComponenteTipo = 2;
                    theComponente.Mensaje = ex.MessageQueueErrorCode + " " + ex.Message;

                    Binternacional.Transversal.Log.ins_error(theComponente);
                }
            }

            catch (Exception ex)
            {
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 2;
                theComponente.Mensaje = ex.Message + " " + ex.StackTrace;

                Binternacional.Transversal.Log.ins_error(theComponente);
            }
            finally
            {
                wobjMessageQueue.Dispose();
                wobjMessageQueue.Close();
            }

        }

        /// <summary>
        /// envio de mensajes Colas MessageQueque microsoft
        /// </summary>
        public static void EnvioMensajeMessageQueue(Binternacional.DTO.ComponenteMQ theComponenteMQ)
        {
            System.Messaging.MessageQueue wobjMessageQueue = null;

            Message wobjMessage = null;
            try
            {
                wobjMessageQueue = new System.Messaging.MessageQueue(".\\Private$\\TransRevQueue");

                MessageQueueTransaction wobjMessageQueueTransaction = new MessageQueueTransaction();
                wobjMessage = new Message();

                wobjMessage.Label = theComponenteMQ.TheComponenteTipo.Descripcion;
                wobjMessage.AppSpecific = 1;
                wobjMessage.Body = theComponenteMQ.Request; 


                wobjMessageQueueTransaction.Begin();

                wobjMessageQueue.Send(wobjMessage,
                                      wobjMessageQueueTransaction);

                wobjMessageQueueTransaction.Commit();
               


                wobjMessageQueue.Dispose();
                wobjMessageQueue.Close();
          
            }
            catch (MessageQueueException ex)
            {

                ///grabar Log ColasMQ
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 2;
                theComponente.Mensaje =ex.ErrorCode+" "+ ex.Message;

                Binternacional.Transversal.Log.ins_error(theComponente);

                if (!ex.Message.ToLower().Contains("timeout"))
                {
                    //Binternacional.DTO.Reversa theReversa = new DTO.Reversa();
                    //theReversa.CodigoTransaccion = "333";
                    //theReversa.TheComponenteCanal.IdCanal = 1;
                    //theReversa.TipoTransaccion = 1;
                    //theReversa.Mensaje = wobjMessage.Body.ToString();
                    //theReversa.TheReversaEstado.IdEstado = 1;

                    //Binternacional.Log.Log.ins_reversa(theReversa);
                    ///grabar Log ColasMQ

                }
                else
                {
                    ///grabar Log ColasMQ
                }
            }


            catch (Exception ex)
            {
                ///grabar Log ColasMQ
                Binternacional.DTO.Componente theComponente = new DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal = 1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 2;
                theComponente.Mensaje = ex.Message;

                Binternacional.Transversal.Log.ins_error(theComponente);
                Console.WriteLine(ex.Message + " " + ex.StackTrace);
                

            }
            finally
            {
                wobjMessageQueue.Close();
                wobjMessageQueue.Dispose();
            }

        }

    }
}
