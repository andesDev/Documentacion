﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Binternacional.Socket
{
    /// <summary>
    /// establece configuracion y conexion entre dos aplicativos via socket
    /// </summary>
    public class Conection
    {

        private string strIpSocket;

        public string StrIpSocket
        {
            get
            {
                if (string.IsNullOrEmpty(this.strIpSocket))
                    this.strIpSocket = "172.10.50.38";//configuracion de IP ConfigurationManager.AppSettings["NombreAdministradorColas"];///leer desde dashboard
                return this.strIpSocket;
            }
            set
            {
                this.strIpSocket = value;
            }
        }

        private int strPuertoSocket;


        public int StrPuertoSocket
        {
            get
            {

                this.strPuertoSocket = 139;//configuracion de IP ConfigurationManager.AppSettings["NombreAdministradorColas"];///leer desde dashboard
                return this.strPuertoSocket;
            }
            set
            {
                this.strPuertoSocket = value;
            }
        }

        private static System.Net.Sockets.Socket m_socClient;
        private static int PORT_MAX;
        private static int PORT_MIN;
        private static int TIMEOUT_MAX;
        private static int TIMEOUT_MIN;




        public static string EnvioPorSocket(string ip, string port, string data, int timeout)
        {
            string str = Convert.ToString(timeout);
            return EnvioPorSocket(ip, port, data, str);
        }


        /// <summary>
        /// recibe IP,puerto, Mensaje y timeout
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="port"></param>
        /// <param name="data"></param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public static string EnvioPorSocket(string ip, string port, string data, string timeout)
        {
            try
            {
                bool flag = true;
                for (int i = 0; i < port.Length; i++)
                {
                    if (!char.IsNumber(port, i))
                    {
                        flag = false;
                    }
                }
                if (!flag)
                {
                    return "NOOK:00001:El puerto debe ser n\x00famerico.";
                }
                flag = true;
                for (int j = 0; j < timeout.Length; j++)
                {
                    if (!char.IsNumber(timeout, j))
                    {
                        flag = false;
                    }
                }
                if (!flag)
                {
                    return "NOOK:00001:El tiempo de espera debe ser n\x00famerico.";
                }
                if (string.IsNullOrEmpty(ip))
                {
                    return "NOOK:00002:Debe especificar la direcci\x00f3n o IP del host.";
                }
                if (string.IsNullOrEmpty(port))
                {
                    return "NOOK:00003:Debe especificar el puerto del host.";
                }
                if (string.IsNullOrEmpty(data))
                {
                    return "NOOK:00004:Debe especificar el dato a enviar al host.";
                }
                if (string.IsNullOrEmpty(timeout))
                {
                    return "NOOK:00005:Debe especificar el tiempo de espera en milisegundos.";
                }
 
                int num3 = int.Parse(timeout);
                string str = ResolverIP(ip);
                string str2 = Connect(str, port, data);
                if (str2.Equals("OK"))
                {
                    str2 = ReceiveData(str, port, num3);
                    CloseSocket();
                }
                return str2;
            }
            catch (SocketException exception)
            {
 
                Binternacional.DTO.Componente theComponente=new  DTO.Componente();

                theComponente.TheComponenteCanal.IdCanal=1;
                theComponente.TheComponenteTipo.IdComponenteTipo = 1;
                theComponente.Mensaje=exception.Message;
             
                Binternacional.Transversal.Log.ins_error(theComponente);
                return string.Concat(new object[] { "NOOK:", exception.ErrorCode, ":", exception.Message });
                
            }
        }
        public static string ResolverIP(string hostname)
        {
            return  Dns.GetHostEntry(hostname).AddressList[0].ToString();
        }


        public static string ReceiveData(string ip, string port, int timeout)
        {
            try
            {
                byte[] buffer = new byte[5];
                m_socClient.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, timeout);
                int byteCount = m_socClient.Receive(buffer, 5, SocketFlags.None);
                char[] chars = new char[byteCount];
                Decoder decoder = Encoding.UTF8.GetDecoder();
                decoder.GetChars(buffer, 0, byteCount, chars, 0);
                string s = new string(chars);
                int size = int.Parse(s);
                byte[] buffer2 = new byte[size];
                byteCount = m_socClient.Receive(buffer2, size, SocketFlags.None);
                char[] chArray2 = new char[byteCount];
                decoder.GetChars(buffer2, 0, byteCount, chArray2, 0);
                return new string(chArray2);
            }
            catch (SocketException exception)
            {
                return string.Concat(new object[] { "NOOK:", exception.ErrorCode, ":", exception.Message });
            }
        }






        public static bool CloseSocket()
        {
            try
            {
                ///cierre conexion de sockets
                m_socClient.Close();
                
            }
            catch (SocketException exception)
            {
                ///grabar log sockets
                return false;
                //return string.Concat(new object[] { "NOOK:", exception.ErrorCode, ":", exception.Message });
            }
            catch (Exception ex)
            {  ///grabar log sockets
                return false;
            }

            return true;
        }

        public static string Connect(string ip, string port, string data)
        {
            try
            {
                m_socClient = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                string ipString = ip;
                string str2 = port;
                int num = Convert.ToInt16(str2, 10);
                IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(ipString), num);
                m_socClient.Connect(remoteEP);
                Console.WriteLine("conexion realizada de forma exitosa");
                string s = data;
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                string str4 = bytes.Length.ToString("D5");
                byte[] buffer = Encoding.UTF8.GetBytes(str4);
                m_socClient.Send(buffer);
                m_socClient.Send(bytes);
                return "OK";
            }
            catch (SocketException exception)
            {
                return string.Concat(new object[] { "NOOK:", exception.ErrorCode, ":", exception.Message });
                ///graba log de Socket
            }
            catch (Exception ex)
            {
                return string.Concat(new object[] { "NOOK:", ex.Message, ":", ex.InnerException });
                ///graba log de Socket
            }
          
        }











        public void Conectar()
        {
            System.Net.Sockets.Socket miPrimerSocket = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);


            // paso 2 - creamos el socket
            try
            {
                IPEndPoint miDireccion = new IPEndPoint(IPAddress.Parse("172.16.50.38"), 139);
                miPrimerSocket.Connect(miDireccion);
            }
            catch (SocketException ex)
            {

            }

        }

        //public void Conectar()
        //{



        //    //creamos el socket
        //    System.Net.Sockets.Socket connection = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        //    IPEndPoint miDireccion = null;

        //    // IPAddress.Any significa que va a escuchar al cliente en toda la red

        //    try
        //    {
        //          miDireccion = new IPEndPoint(IPAddress.Parse(this.StrIpSocket), this.StrPuertoSocket);

        //        connection.Bind(miDireccion); // Asociamos el socket a miDireccion
        //        connection.Listen(1); // Lo ponemos a escucha

        //        Console.WriteLine("Escuchando...");

        //        System.Net.Sockets.Socket mensajeria = connection.Accept();
        //        //creamos el nuevo socket, para comenzar a trabajar con él
        //        //La aplicación queda en reposo hasta que el socket se conecte a el cliente
        //        //Una vez conectado, la aplicación sigue su camino 

        //        Console.WriteLine("Conectado con exito");


        //        /*Aca ponemos todo lo que queramos hacer con el socket, osea antes de

        //        cerrarlo je*/

        //        connection.Dispose();
        //        connection.Close(); //Luego lo cerramos



        //    }

        //    catch (SocketException error)
        //    {

        //        Console.WriteLine("Error: {0}", error.ToString());

        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Error: {0}", ex.Message);
        //    }
        //    finally
        //    {
        //        connection.Dispose();
        //        connection.Close(); //Luego lo cerramos
        //    }


        //    Console.WriteLine("Presione cualquier tecla para terminar");

        //    Console.ReadLine();


        //}
        const int PORT_NO = 139;
        const string SERVER_IP = "172.16.50.38";
        public void EnviarMensaje()
        {

            string textToSend = "hello world";

            //---create a TCPClient object at the IP and port no.---
            TcpClient client = new TcpClient(SERVER_IP, PORT_NO);
            NetworkStream nwStream = client.GetStream();
            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);

            //---send the text---
            Console.WriteLine("Sending : " + textToSend);
            nwStream.Write(bytesToSend, 0, bytesToSend.Length);

            //---read back the text---
            byte[] bytesToRead = new byte[client.ReceiveBufferSize];
            int bytesRead = nwStream.Read(bytesToRead, 0, client.ReceiveBufferSize);

            Console.WriteLine("Received : " + Encoding.ASCII.GetString(bytesToRead, 0, bytesRead));
            Console.ReadLine();
            client.Close();
        }
        //public void Conectar()
        //{
        //    TcpClient socketForServer = new TcpClient();

        //    System.Net.Sockets.Socket miPrimerSocket = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);


        //    // paso 2 - creamos el socket
        //    try
        //    {
        //        IPEndPoint miDireccion = new IPEndPoint(IPAddress.Parse("172.16.50.38"), 139);

        //        //paso 3 - Acá debemos poner la Ip del servidor, y el puerto de escucha del servidor

        //        //Yo puse esa porque corrí las dos aplicaciones en la misma pc
        //        miPrimerSocket.Connect(miDireccion); // Conectamos               

        //        TcpClient client = miPrimerSocket.Accept();
        //        string str = "mensaje de prueba a socket gateway";
        //        byte[] buffer = new byte[12];


        //        miPrimerSocket.Send(buffer, Encoding.UTF8.GetBytes(str), 0, str.Length, 10000);


        //        Console.WriteLine("Conectado con exito");


        //        //miPrimerSocket.Send(streamWriter);
        //        //NetworkStream networkStream = socketForServer.GetStream();
        //        //StreamReader streamReader = new System.IO.StreamReader(networkStream);

        //        //StreamWriter streamWriter = new System.IO.StreamWriter(networkStream);


        //        //string outputString = streamReader.ReadLine();
        //        //Console.WriteLine(outputString);
        //        //streamWriter.WriteLine("Mensaje desde el Cliente");
        //        //streamWriter.Flush();

        //        miPrimerSocket.Close();
        //    }
        //    catch (SocketException ex)
        //    {
        //        Console.WriteLine("Error: {0}", ex.Message);
        //    }

        //    catch (Exception error)
        //    {

        //        Console.WriteLine("Error: {0}", error.ToString());

        //    }

        //    Console.WriteLine("Presione cualquier tecla para terminar");

        //    Console.ReadLine();


        //}
    }
}
